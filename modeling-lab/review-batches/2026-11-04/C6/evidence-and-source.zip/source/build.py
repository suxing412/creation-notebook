import json,pathlib,hashlib,copy
R=pathlib.Path(__file__).resolve().parents[1];ids=['002','006','007','008','010'];patches=[];mapping=[]
for f,key,target in [('catalog-snapshot.json',None,'docs/catalog.json'),('notebook-index-snapshot.json','models','docs/notebook-index.json')]:
 original=json.load(open(R/f));candidate=copy.deepcopy(original);entries=candidate[key]if key else candidate;ops=[]
 for id in ids:
  matches=[(i,e)for i,e in enumerate(entries)if e['id']==id];assert len(matches)==1;i,e=matches[0];prefix=(f'/{key}'if key else'')+f'/{i}'
  assert e.get('name',e.get('title')) == {'002':'潮翼','006':'折页','007':'回环','008':'透幕','010':'栖格'}[id]
  label={'label':'形体习作','basis':'review_opinion','reviewId':'C6','notHistoricalOrTechnicalCertification':True}
  ops += [{'op':'test','path':prefix+'/id','value':id},{'op':'test','path':prefix+('/title'if key else'/name'),'value':e.get('title',e.get('name'))},{'op':'add','path':prefix+'/reviewClassification','value':label}];e['reviewClassification']=label
  mapping.append({'target':target,'id':id,'title':e.get('title',e.get('name')),'arrayIndex':i,'kindPreserved':e['kind'],'pathPreserved':e.get('path',e.get('detail'))})
 out=f.replace('-snapshot','-candidate');(R/out).write_text(json.dumps(candidate,ensure_ascii=False,indent=2))
 patches.append({'target':target,'baseCommit':'a63af753e2fa71793a5d4a4ac4ae4a2d99ce437e','baseSnapshotSHA256':hashlib.sha256((R/f).read_bytes()).hexdigest(),'operations':ops})
 # prove exact structure roundtrip: removing only new field returns original
 restored=copy.deepcopy(candidate)
 for e in (restored[key]if key else restored):
  if e['id']in ids:e.pop('reviewClassification')
 assert restored==original
(R/'codex-label-patch.json').write_text(json.dumps({'reviewId':'C6','notApplied':True,'frontendEdits':False,'patches':patches},ensure_ascii=False,indent=2));(R/'qa/id-mapping-and-invariants.json').write_text(json.dumps({'mapping':mapping,'onlyNewReviewClassificationFields':True,'unchangedCountsAndFileReferences':True,'matchingIdsExactlyOnce':True},ensure_ascii=False,indent=2))
