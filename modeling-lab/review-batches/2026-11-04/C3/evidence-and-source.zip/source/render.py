import bpy,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parents[1]
for variant in ['A','B']:
 for res in ['original','256','128']:
  bpy.ops.wm.read_factory_settings(use_empty=True)
  p=R/'baseline/assets'/f'well-{variant}-LOD1.glb' if res=='original' else R/'assets'/f'well-{variant}-LOD1-batched-{res}.glb'
  bpy.ops.import_scene.gltf(filepath=str(p));sc=bpy.context.scene;sc.render.engine='CYCLES';sc.cycles.device='CPU';sc.cycles.samples=24;sc.cycles.use_denoising=False;sc.cycles.seed=0;sc.render.resolution_x=480;sc.render.resolution_y=480;sc.render.resolution_percentage=100
  sc.world=bpy.data.worlds.new('World');sc.world.use_nodes=True;sc.world.node_tree.nodes['Background'].inputs[0].default_value=(.55,.59,.65,1);sc.world.node_tree.nodes['Background'].inputs[1].default_value=.65
  bpy.ops.object.light_add(type='AREA',location=(1,-3,6));bpy.context.object.data.energy=650;bpy.context.object.data.size=4
  bpy.ops.object.camera_add();cam=bpy.context.object;sc.camera=cam;cam.data.type='ORTHO'
  for suffix,pos,target,scale in [('whole',(4,-6,4),(0,0,1.2),4.7),('opening',(2,-3,2),(0,0,.65),2.7)]:
   cam.location=pos;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=scale;sc.render.filepath=str(R/'qa'/f'{variant}-{res}-{suffix}.png');bpy.ops.render.render(write_still=True)
