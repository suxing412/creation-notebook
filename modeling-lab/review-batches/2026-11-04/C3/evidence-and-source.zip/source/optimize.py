import pathlib,struct,json,copy,io,hashlib,collections
import numpy as np
from PIL import Image
ROOT=pathlib.Path(__file__).resolve().parents[1]
DT={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}; SZ={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}
def read(path):
 b=pathlib.Path(path).read_bytes(); magic,ver,length=struct.unpack_from('<III',b);assert magic==0x46546c67 and ver==2 and length==len(b)
 n,t=struct.unpack_from('<II',b,12);assert t==0x4e4f534a
 j=json.loads(b[20:20+n]); m,t=struct.unpack_from('<II',b,20+n);assert t==0x004e4942
 return j,b[28+n:28+n+m]
def arr(j,b,k):
 a=j['accessors'][k];assert 'sparse' not in a and not a.get('normalized',False)
 v=j['bufferViews'][a['bufferView']];dtype=np.dtype(DT[a['componentType']]); nc=SZ[a['type']];stride=v.get('byteStride',dtype.itemsize*nc)
 return np.ndarray((a['count'],nc),dtype=dtype,buffer=b,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(stride,dtype.itemsize)).copy()
def optimize(src,dst,res):
 assert res in [128,256], 'Only tested 128/256 allowed'
 j,b=read(src);assert not j.get('animations') and not j.get('skins')
 assert all(set(n)<= {'name','mesh','translation'} for n in j['nodes']), 'Only translation-only static leaf nodes supported'
 assert len(j['scenes'])==1 and sorted(j['scenes'][0]['nodes'])==list(range(len(j['nodes'])))
 assert sorted(n['mesh'] for n in j['nodes'])==list(range(len(j['meshes'])))
 out={k:copy.deepcopy(v) for k,v in j.items() if k not in ['nodes','meshes','scenes','accessors','bufferViews','buffers']};out.update(nodes=[],meshes=[],scenes=[{'nodes':[]}],accessors=[],bufferViews=[]);bin=bytearray(); mapping=[]
 def bv(data):
  while len(bin)%4:bin.append(0)
  k=len(out['bufferViews']);out['bufferViews'].append({'buffer':0,'byteOffset':len(bin),'byteLength':len(data)});bin.extend(data);return k
 def accessor(a,typ,comp):
  a=np.ascontiguousarray(a,dtype=DT[comp]);r={'bufferView':bv(a.tobytes()),'componentType':comp,'count':len(a),'type':typ}
  if typ=='VEC3':r.update(min=a.min(0).tolist(),max=a.max(0).tolist())
  k=len(out['accessors']);out['accessors'].append(r);return k
 groups=collections.defaultdict(list)
 for ni,node in enumerate(j['nodes']):
  for pi,p in enumerate(j['meshes'][node['mesh']]['primitives']):
   assert set(p)<= {'attributes','indices','material','mode'} and p.get('mode',4)==4
   groups[(p.get('material',-1),tuple(sorted(p['attributes'])))].append((ni,pi,p))
 for (mat,attrs),ps in groups.items():
  data={a:[] for a in attrs};inds=[];offset=0;source=[]
  for ni,pi,p in ps:
   arrays={a:arr(j,b,p['attributes'][a]) for a in attrs};arrays['POSITION']=(arrays['POSITION'].astype(np.float64)+np.array(j['nodes'][ni].get('translation',[0,0,0]))).astype(np.float32);ct=len(arrays['POSITION']);assert all(len(x)==ct for x in arrays.values())
   ix=arr(j,b,p['indices']).reshape(-1);assert len(ix)%3==0 and int(ix.max())<ct
   inds.append(ix.astype(np.uint32)+offset)
   source.append({'node':ni,'name':j['nodes'][ni]['name'],'translation':j['nodes'][ni].get('translation',[0,0,0]),'primitive':pi,'vertexStart':offset,'vertexCount':ct,'indexStart':sum(len(q)for q in inds[:-1]),'indexCount':len(ix)})
   for a in attrs:data[a].append(arrays[a])
   offset+=ct
  p={'attributes':{a:accessor(np.concatenate(data[a]),j['accessors'][ps[0][2]['attributes'][a]]['type'],5126) for a in attrs},'indices':accessor(np.concatenate(inds).reshape(-1,1),'SCALAR',5125),'material':mat}
  k=len(out['meshes']);out['meshes'].append({'name':'material_batch_'+str(mat),'primitives':[p]});out['nodes'].append({'name':'static_batch_'+str(mat),'mesh':k});out['scenes'][0]['nodes'].append(k);mapping.append({'batch':k,'sources':source})
 normal_indices={m['normalTexture']['index'] for m in j['materials'] if 'normalTexture'in m};normal_sources={j['textures'][i]['source']for i in normal_indices}
 for ii,im in enumerate(j['images']):
  v=j['bufferViews'][im['bufferView']];raw=b[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']];img=Image.open(io.BytesIO(raw)).convert('RGB');img=img.resize((res,res),Image.Resampling.LANCZOS)
  if ii in normal_sources:
   a=np.asarray(img).astype(float)/255*2-1;a/=np.maximum(np.linalg.norm(a,axis=2,keepdims=True),1e-9);img=Image.fromarray(np.clip(np.rint((a+1)*127.5),0,255).astype('uint8'))
  f=io.BytesIO();img.save(f,format='PNG',optimize=True);out['images'][ii]={'mimeType':'image/png','bufferView':bv(f.getvalue()),'name':im.get('name','texture_'+str(ii))}
 out['buffers']=[{'byteLength':len(bin)}];js=json.dumps(out,separators=(',',':')).encode();js+=b' '*((-len(js))%4);bin+=b'\0'*((-len(bin))%4)
 result=struct.pack('<III',0x46546c67,2,28+len(js)+len(bin))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(bin),0x004e4942)+bin
 pathlib.Path(dst).write_bytes(result);return mapping
if __name__=='__main__':
 for v in ['A','B']:
  for res in [256,128]:
   src=ROOT/'baseline/assets'/f'well-{v}-LOD1.glb';dst=ROOT/'assets'/f'well-{v}-LOD1-batched-{res}.glb';mapping=optimize(src,dst,res)
   (ROOT/'qa'/f'{dst.stem}-mapping.json').write_text(json.dumps(mapping,indent=2))
