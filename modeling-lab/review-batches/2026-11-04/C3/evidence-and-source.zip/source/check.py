from optimize import *
import math

def audit(path):
 j,b=read(path);tris=[];attrs=[];pr=[]
 for node in j['nodes']:
  for p in j['meshes'][node['mesh']]['primitives']:
   pos=arr(j,b,p['attributes']['POSITION']).astype(float)+np.array(node.get('translation',[0,0,0]));ix=arr(j,b,p['indices']).reshape(-1,3);t=pos[ix];tris.extend(t)
   other={a:arr(j,b,k)[ix]for a,k in p['attributes'].items()if a!='POSITION'}
   for k,tr in enumerate(t):attrs.append((p['material'],tuple(sorted((a,tuple(q[k].reshape(-1)))for a,q in other.items())),tuple(np.round(tr.reshape(-1),6))))
   pr.append({'triangles':len(ix),'material':p['material'],'uv':'TEXCOORD_0'in p['attributes']})
 t=np.array(tris);area=np.linalg.norm(np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]),axis=1)
 imgs=[]
 for im in j['images']:
  v=j['bufferViews'][im['bufferView']];raw=b[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']];i=Image.open(io.BytesIO(raw));imgs.append({'bytes':len(raw),'size':list(i.size),'sha256':hashlib.sha256(raw).hexdigest()})
 return {'file':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size,'primitives':len(pr),'triangles':len(t),'degenerate':int(sum(area<1e-10)),'signedVolume':float(np.einsum('ij,ij->i',t[:,0],np.cross(t[:,1],t[:,2])).sum()/6),'images':imgs,'imageBytes':sum(i['bytes']for i in imgs),'bounds':[t.min((0,1)).tolist(),t.max((0,1)).tolist()]},attrs
rows=[]
for v in ['A','B']:
 original=ROOT/'baseline/assets'/f'well-{v}-LOD1.glb';base,attrs=audit(original);rows.append(base)
 for res in [256,128]:
  p=ROOT/'assets'/f'well-{v}-LOD1-batched-{res}.glb';r,other=audit(p)
  # Sorted multiset preserves material, vertex normals and UV (full float), with world positions rounded only for float translation bake.
  r['orientedTrianglesMaterialNormalUVMatch6dp']=collections.Counter(attrs)==collections.Counter(other);r['baselineSHA256']=base['sha256'];r['reductionPercent']=100*(1-r['bytes']/base['bytes']);assert r['orientedTrianglesMaterialNormalUVMatch6dp'];assert r['degenerate']==base['degenerate']==0;rows.append(r)
(ROOT/'qa/metrics.json').write_text(json.dumps(rows,indent=2))
# Test unsupported input fails instead of silently dropping transforms/skin/animation.
failed=[]
for res in [0,64,512,-1]:
 try:optimize(original,ROOT/'qa/unexpected.glb',res)
 except AssertionError:failed.append(res)
assert len(failed)==4
(ROOT/'qa/invalid-inputs.json').write_text(json.dumps({'resolutionRejected':failed,'supportedOnly':[128,256]}))
print([(r['file'],r['bytes'],r['primitives'],r['triangles'])for r in rows])
