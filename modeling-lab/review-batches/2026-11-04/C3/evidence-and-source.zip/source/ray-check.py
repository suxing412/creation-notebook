from optimize import *
def hit(ts,origin,direction):
 e1=ts[:,1]-ts[:,0];e2=ts[:,2]-ts[:,0];h=np.cross(np.broadcast_to(direction,e2.shape),e2);a=np.einsum('ij,ij->i',e1,h);ok=np.abs(a)>1e-10;f=np.divide(1,a,out=np.zeros_like(a),where=ok);s=origin-ts[:,0];u=f*np.einsum('ij,ij->i',s,h);q=np.cross(s,e1);v=f*np.einsum('j,ij->i',direction,q);t=f*np.einsum('ij,ij->i',e2,q);return int(np.sum(ok&(u>=0)&(v>=0)&(u+v<=1)&(t>1e-7)))
rows=[]
for p in sorted((ROOT/'assets').glob('*.glb')):
 j,b=read(p);mapping=json.loads((ROOT/'qa'/f'{p.stem}-mapping.json').read_text());tri=[]
 for group in mapping:
  pr=j['meshes'][group['batch']]['primitives'][0];pos=arr(j,b,pr['attributes']['POSITION']);ix=arr(j,b,pr['indices']).reshape(-1)
  for s in group['sources']:
   if any(k in s['name'] for k in ['liner','rim','collar','apron']):tri.extend(pos[ix[s['indexStart']:s['indexStart']+s['indexCount']].reshape(-1,3)])
 ts=np.array(tri);samples=[{'xz':[x,z],'hits':hit(ts,np.array([x,.8,z]),np.array([0.,-1.,0.]))}for x,z in [(0,0),(.2,0),(-.2,0),(0,.2),(0,-.2)]];assert not any(s['hits']for s in samples);rows.append({'asset':p.name,'samples':samples})
(ROOT/'qa/bore-rays.json').write_text(json.dumps(rows,indent=2))
