from optimize import *
def check(t):
 t=np.round(t,6);ed=collections.Counter();di=collections.Counter();faces=collections.Counter()
 for tri in t:
  q=tuple(tuple(x)for x in tri);faces[min(q[i:]+q[:i]for i in range(3))]+=1
  for a,b in zip(q,q[1:]+q[:1]):ed[tuple(sorted((a,b)))]+=1;di[(a,b)]+=1
 return {'nonTwoEdges':sum(v!=2 for v in ed.values()),'directedEdgeMismatches':sum(di[(b,a)]!=n for(a,b),n in di.items()),'duplicateOrientedTriangles':sum(n-1 for n in faces.values()),'degenerate':int(sum(np.linalg.norm(np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]),axis=1)<1e-10)),'signedVolume':float(np.einsum('ij,ij->i',t[:,0],np.cross(t[:,1],t[:,2])).sum()/6)}
rows=[]
for v in ['A','B']:
 for res in [256,128]:
  p=ROOT/'assets'/f'well-{v}-LOD1-batched-{res}.glb';j,b=read(p);m=json.loads((ROOT/'qa'/f'{p.stem}-mapping.json').read_text());sources=[]
  for group in m:
   pr=j['meshes'][group['batch']]['primitives'][0];pos=arr(j,b,pr['attributes']['POSITION']);idx=arr(j,b,pr['indices']).reshape(-1)
   for s in group['sources']:
    t=pos[idx[s['indexStart']:s['indexStart']+s['indexCount']].reshape(-1,3)];sources.append({'name':s['name'],**check(t)})
  rows.append({'asset':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'sourceShells':sources,'note':'Per original source shell via reversible batch ranges; does not globally weld legitimate separate shells or assert all pairwise intersections absent.'})
(ROOT/'qa/topology.json').write_text(json.dumps(rows,indent=2));print([(r['asset'],max(s['nonTwoEdges']for s in r['sourceShells']),sum(s['degenerate']for s in r['sourceShells']),min(s['signedVolume']for s in r['sourceShells']))for r in rows])
