from PIL import Image,ImageDraw
from pathlib import Path
R=Path(__file__).resolve().parents[1];out=Image.new('RGB',(1440,2040),(242,241,236));d=ImageDraw.Draw(out)
for row,(v,view)in enumerate([(v,view)for v in ['A','B']for view in ['whole','opening']]):
 for col,res in enumerate(['original','256','128']):
  im=Image.open(R/'qa'/f'{v}-{res}-{view}.png').convert('RGB');out.paste(im,(col*480,row*510+30));d.text((col*480+12,row*510+8),f'{v} | {view} | '+ ('Original LOD1 512px' if res=='original'else f'Batched LOD1 {res}px'),fill=(20,20,20))
out.save(R/'qa/well-lod-comparison.png')
