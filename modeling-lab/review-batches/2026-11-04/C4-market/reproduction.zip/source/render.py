import bpy
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parents[1]
for label,rel in [('before','baseline/market-C2.glb'),('after','assets/market-C2-C4-display.glb')]:
 bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(R/rel));objects=[o for o in bpy.context.scene.objects if o.type=='MESH'];pts=[o.matrix_world@Vector(v)for o in objects for v in o.bound_box];lo=Vector(tuple(min(p[k]for p in pts)for k in range(3)));hi=Vector(tuple(max(p[k]for p in pts)for k in range(3)));center=(lo+hi)/2;size=max(hi-lo)
 sc=bpy.context.scene;sc.render.engine='CYCLES';sc.cycles.device='CPU';sc.cycles.samples=32;sc.cycles.seed=0;sc.cycles.use_denoising=False;sc.render.resolution_x=640;sc.render.resolution_y=480;sc.render.resolution_percentage=100
 sc.world=bpy.data.worlds.new('World');sc.world.use_nodes=True;sc.world.node_tree.nodes['Background'].inputs[0].default_value=(.65,.68,.72,1);sc.world.node_tree.nodes['Background'].inputs[1].default_value=.7
 bpy.ops.object.light_add(type='AREA',location=center+Vector((size,-size,size*2)));bpy.context.object.data.energy=450; bpy.context.object.data.size=size
 bpy.ops.object.camera_add(location=center+Vector((size,-size*1.6,size*1.5)));cam=bpy.context.object;cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=size*1.6;sc.camera=cam
 for checker in [False,True]:
  if checker:
   mat=bpy.data.materials.new('QA_checker_only');mat.use_nodes=True;ns=mat.node_tree.nodes;ls=mat.node_tree.links;t=ns.new('ShaderNodeTexChecker');t.inputs['Scale'].default_value=4;t.inputs['Color1'].default_value=(.08,.12,.16,1);t.inputs['Color2'].default_value=(.85,.7,.38,1);uv=ns.new('ShaderNodeTexCoord');ls.new(uv.outputs['UV'],t.inputs['Vector']);ls.new(t.outputs['Color'],ns.get('Principled BSDF').inputs['Base Color'])
   for o in objects:o.data.materials.clear();o.data.materials.append(mat)
  sc.render.filepath=str(R/'qa'/(f'{label}-'+('checker.png'if checker else'material.png')));bpy.ops.render.render(write_still=True)
