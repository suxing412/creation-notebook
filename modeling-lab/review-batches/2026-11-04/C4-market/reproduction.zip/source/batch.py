import pathlib,struct,json,copy,io,hashlib,collections
import numpy as np
from PIL import Image
ROOT=pathlib.Path(__file__).resolve().parents[1]
DT={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}; SZ={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}
def read(path):
 b=pathlib.Path(path).read_bytes(); magic,ver,length=struct.unpack_from('<III',b);assert magic==0x46546c67 and ver==2 and length==len(b)
 n,t=struct.unpack_from('<II',b,12);assert t==0x4e4f534a
 j=json.loads(b[20:20+n]); m,t=struct.unpack_from('<II',b,20+n);assert t==0x004e4942
 return j,b[28+n:28+n+m]
def arr(j,b,k):
 a=j['accessors'][k];assert 'sparse' not in a and not a.get('normalized',False)
 v=j['bufferViews'][a['bufferView']];dtype=np.dtype(DT[a['componentType']]); nc=SZ[a['type']];stride=v.get('byteStride',dtype.itemsize*nc)
 return np.ndarray((a['count'],nc),dtype=dtype,buffer=b,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(stride,dtype.itemsize)).copy()
def optimize(src,dst,res):
 assert res in [128,256], 'Only tested 128/256 allowed'
 j,b=read(src);assert not j.get('animations') and not j.get('skins')
 assert len(j['scenes'])==1
 originals=copy.deepcopy(j['nodes']);flat=[];seen=set()
 def walk(ni,translation):
  assert ni not in seen, 'DAG instances/cycles not supported';seen.add(ni);n=originals[ni]
  assert set(n)<= {'name','mesh','translation','children'}, 'Only static translation hierarchies'
  t=translation+np.array(n.get('translation',[0,0,0]))
  if 'mesh' in n:flat.append({'name':n.get('name',str(ni)),'mesh':n['mesh'],'translation':t.tolist(),'_active':True,'_originalNode':ni})
  for child in n.get('children',[]):walk(child,t)
 for ni in j['scenes'][0]['nodes']:walk(ni,np.zeros(3))
 assert len(seen)==len(originals), 'Unreferenced original nodes require manual review'
 used={n['mesh']for n in flat};assert len(used)==len(flat), 'Instances require separate handling'
 for mi,m in enumerate(j['meshes']):
  if mi not in used:flat.append({'name':m.get('name','orphan_'+str(mi)),'mesh':mi,'translation':[0,0,0],'_active':False,'_originalNode':None})
 j['nodes']=flat
 out={k:copy.deepcopy(v) for k,v in j.items() if k not in ['nodes','meshes','scenes','accessors','bufferViews','buffers']};out.update(nodes=[],meshes=[],scenes=[{'nodes':[]}],accessors=[],bufferViews=[]);bin=bytearray(); mapping=[]
 def bv(data):
  while len(bin)%4:bin.append(0)
  k=len(out['bufferViews']);out['bufferViews'].append({'buffer':0,'byteOffset':len(bin),'byteLength':len(data)});bin.extend(data);return k
 def accessor(a,typ,comp):
  a=np.ascontiguousarray(a,dtype=DT[comp]);r={'bufferView':bv(a.tobytes()),'componentType':comp,'count':len(a),'type':typ}
  if typ=='VEC3':r.update(min=a.min(0).tolist(),max=a.max(0).tolist())
  k=len(out['accessors']);out['accessors'].append(r);return k
 groups=collections.defaultdict(list)
 for ni,node in enumerate(j['nodes']):
  for pi,p in enumerate(j['meshes'][node['mesh']]['primitives']):
   assert set(p)<= {'attributes','indices','material','mode'} and p.get('mode',4)==4
   groups[(p.get('material',-1),tuple(sorted(p['attributes'])),node['_active'])].append((ni,pi,p))
 for (mat,attrs,active),ps in groups.items():
  data={a:[] for a in attrs};inds=[];offset=0;source=[]
  for ni,pi,p in ps:
   arrays={a:arr(j,b,p['attributes'][a]) for a in attrs};arrays['POSITION']=(arrays['POSITION'].astype(np.float64)+np.array(j['nodes'][ni].get('translation',[0,0,0]))).astype(np.float32);ct=len(arrays['POSITION']);assert all(len(x)==ct for x in arrays.values())
   ix=arr(j,b,p['indices']).reshape(-1);assert len(ix)%3==0 and int(ix.max())<ct
   inds.append(ix.astype(np.uint32)+offset)
   source.append({'node':j['nodes'][ni]['_originalNode'],'originalMesh':j['nodes'][ni]['mesh'],'activeScene':active,'name':j['nodes'][ni]['name'],'translation':j['nodes'][ni].get('translation',[0,0,0]),'primitive':pi,'vertexStart':offset,'vertexCount':ct,'indexStart':sum(len(q)for q in inds[:-1]),'indexCount':len(ix)})
   for a in attrs:data[a].append(arrays[a])
   offset+=ct
  p={'attributes':{a:accessor(np.concatenate(data[a]),j['accessors'][ps[0][2]['attributes'][a]]['type'],5126) for a in attrs},'indices':accessor(np.concatenate(inds).reshape(-1,1),'SCALAR',5123 if offset<=65535 else 5125),'material':mat}
  k=len(out['meshes']);out['meshes'].append({'name':('active_' if active else 'orphan_')+'material_batch_'+str(mat),'primitives':[p]})
  if active:
   nk=len(out['nodes']);out['nodes'].append({'name':'static_batch_'+str(mat),'mesh':k});out['scenes'][0]['nodes'].append(nk)
  mapping.append({'batch':k,'activeScene':active,'sources':source})
 assert not j.get('images'), 'This tile pilot supports no embedded images'
 out['buffers']=[{'byteLength':len(bin)}];js=json.dumps(out,separators=(',',':')).encode();js+=b' '*((-len(js))%4);bin+=b'\0'*((-len(bin))%4)
 result=struct.pack('<III',0x46546c67,2,28+len(js)+len(bin))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(bin),0x004e4942)+bin
 pathlib.Path(dst).write_bytes(result);return mapping
if __name__=='__main__':
 src=ROOT/'baseline/market-C2.glb';dst=ROOT/'assets/market-C2-C4.glb'
 mapping=optimize(src,dst,256)
 (ROOT/'qa/node-mapping.json').write_text(json.dumps(mapping,indent=2))
