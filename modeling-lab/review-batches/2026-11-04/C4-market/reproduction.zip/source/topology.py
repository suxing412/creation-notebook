from batch import *
def geo(t):
 t=np.round(t,5);e=collections.Counter();d=collections.Counter();faces=collections.Counter()
 for tr in t:
  q=tuple(tuple(p)for p in tr);faces[min(q[i:]+q[:i]for i in range(3))]+=1
  for a,b in zip(q,q[1:]+q[:1]):e[tuple(sorted((a,b)))]+=1;d[(a,b)]+=1
 return {'nonTwoEdges':sum(n!=2 for n in e.values()),'windingErrors':sum(d[(b,a)]!=n for(a,b),n in d.items()),'duplicateOriented':sum(n-1 for n in faces.values()),'degenerate':int(sum(np.linalg.norm(np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]),axis=1)<1e-10))}
j,b=read(ROOT/'baseline/market-C2.glb');o,c=read(ROOT/'assets/market-C2-C4.glb');mapping=json.loads((ROOT/'qa/node-mapping.json').read_text());rows=[]
for g in mapping:
 p=o['meshes'][g['batch']]['primitives'][0];pos=arr(o,c,p['attributes']['POSITION']);ix=arr(o,c,p['indices']).reshape(-1)
 for s in g['sources']:
  q=j['meshes'][s['originalMesh']]['primitives'][0];bp=arr(j,b,q['attributes']['POSITION']).astype(float)+np.array(s['translation']);bi=arr(j,b,q['indices']).reshape(-1,3);before=geo(bp[bi]);after=geo(pos[ix[s['indexStart']:s['indexStart']+s['indexCount']].reshape(-1,3)]);assert before==after
  rows.append({'name':s['name'],'originalMesh':s['originalMesh'],'before':before,'after':after})
(ROOT/'qa/topology-before-after.json').write_text(json.dumps(rows,indent=2));print('unchanged',len(rows),'nonTwoEdges',sum(r['after']['nonTwoEdges']for r in rows),'winding',sum(r['after']['windingErrors']for r in rows))
