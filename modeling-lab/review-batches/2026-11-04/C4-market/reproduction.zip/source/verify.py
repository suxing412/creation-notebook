from batch import *
src=ROOT/'baseline/market-C2.glb';dst=ROOT/'assets/market-C2-C4.glb';j,b=read(src);o,c=read(dst);mapping=json.loads((ROOT/'qa/node-mapping.json').read_text());rows=[];maxerr=0;materialsSame=j['materials']==o['materials'];assert materialsSame
for group in mapping:
 p=o['meshes'][group['batch']]['primitives'][0];dest={a:arr(o,c,k)for a,k in p['attributes'].items()};di=arr(o,c,p['indices']).reshape(-1)
 for s in group['sources']:
  sp=j['meshes'][s['originalMesh']]['primitives'][s['primitive']];orig={a:arr(j,b,k)for a,k in sp['attributes'].items()};si=arr(j,b,sp['indices']).reshape(-1);start=s['vertexStart'];end=start+s['vertexCount'];beforeWorld=orig['POSITION'].astype(float)+np.array(s['translation']);afterWorld=dest['POSITION'][start:end];err=float(abs(beforeWorld-afterWorld).max());maxerr=max(maxerr,err)
  assert err<=1e-6
  assert all(np.array_equal(a,dest[key][start:end])for key,a in orig.items()if key!='POSITION')
  assert np.array_equal(si,di[s['indexStart']:s['indexStart']+s['indexCount']]-start);assert sp['material']==p['material']
  t=afterWorld[si.reshape(-1,3)];areas=np.linalg.norm(np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]),axis=1)
  uv=orig['TEXCOORD_0'][si.reshape(-1,3)];a=uv[:,1]-uv[:,0];d=uv[:,2]-uv[:,0];ua=abs(a[:,0]*d[:,1]-a[:,1]*d[:,0]);deg=int(sum(areas<1e-10));zeroUV=int(sum((areas>=1e-10)&(ua<1e-10)))
  vol=float(np.einsum('ij,ij->i',t[:,0],np.cross(t[:,1],t[:,2])).sum()/6)
  rows.append({'originalNode':s['node'],'originalMesh':s['originalMesh'],'activeScene':s['activeScene'],'name':s['name'],'triangles':len(t),'degenerate':deg,'zeroUVForNondegenerate':zeroUV,'signedVolume':vol,'maxWorldPositionError':err,'normalUVIndexMaterialExact':True})
assert len(rows)==554;assert sum(r['activeScene']for r in rows)==524
used={n['mesh']for n in o['nodes']};activePrimitive=sum(len(o['meshes'][k]['primitives'])for k in used);orphanPrimitive=sum(len(m['primitives'])for k,m in enumerate(o['meshes'])if k not in used);assert activePrimitive+orphanPrimitive<=30
result={'sourceSHA256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidateSHA256':hashlib.sha256(dst.read_bytes()).hexdigest(),'checkerSHA256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'originalBytes':src.stat().st_size,'candidateBytes':dst.stat().st_size,'beforeActivePrimitives':524,'beforeStoredPrimitives':554,'afterActivePrimitives':activePrimitive,'afterOrphanPrimitives':orphanPrimitive,'afterStoredPrimitives':activePrimitive+orphanPrimitive,'materials':len(o['materials']),'maxWorldPositionError':maxerr,'rows':rows}
(ROOT/'qa/C4-validation.json').write_text(json.dumps(result,indent=2));print({k:v for k,v in result.items()if k!='rows'});print('degenerate',sum(r['degenerate']for r in rows),'zeroUV',sum(r['zeroUVForNondegenerate']for r in rows))
