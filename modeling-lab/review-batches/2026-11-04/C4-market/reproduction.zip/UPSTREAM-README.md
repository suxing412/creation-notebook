# C4 市肆静态合批候选 v1
2026-11-04。仅市肆独立候选，不代表全库C4完成；未改main或公共网页。

## 推荐文件
assets/market-C2-C4-display.glb：文件共14个primitive，其中11个进入scene，3个保留为未引用mesh。原文件554个primitive包含524个活跃mesh及30个未引用旧mesh；不能把554全部叫原场景draw call。
实际文件3,537,624→1,917,088B。材质仍10，无贴图，不虚构纹理优化。另保留纯静态13图元版market-C2-C4.glb（1,916,208B），仅作研究对照，优先使用display版。

## 为什么推荐14而不是13
display版将sample_ground、route_、boundary_分成各自独立命名批组。它们与建筑即使同材质也不合并，便于封面/浏览继续按这些名称模式隐藏地面、路线、边界，不误隐藏建筑。原单对象名称与选择粒度不再原样保留，其他任意节点查找/点击逻辑需使用qa/node-mapping-display.json适配，不能冒称任意现有前端可直接无修改替换。

当前输入无动画/蒙皮/旋转/缩放、全不透明材质，名称审查没有门扇/车轮等已声明可动件。此版限定静态展示，若以后要逐摊位/货品交互或独立动画应回到baseline，或按映射重新分组，不用于逐对象物理。父节点平移正确累计后烘入顶点，原独立origin保持场景世界位置。

## 真实检查
位置烘入32位float最大误差4.172325134277344e-7场景米，UV/法线/材质/有向索引逐原primitive精确保留。不是位置逐字节无损，精确回退采用baseline原件。
554个原壳分别保持闭合/有向边一致、无退化；前后拓扑计数一致，5位坐标比较用于边身份。非退化三角UV零面积0。原有接触/穿插不靠合批解决，不声称所有构件穿插为0。
30个原来未引用的mesh按3个材质批次仍存在于GLB但不进入scene，未静默删除、未突然显示。它们UV本来按网格本地单位生成，不能冒称已经有确定世界摆位。完整原件及每个原节点/mesh的范围映射保留。
qa/C4-display-validation.json与topology-display-before-after.json绑定实际文件与检查器；纯静态对照也有独立报告。4张同机位原材质/棋盘CPU图源于重新导入display实际文件，32 samples seed0。图中主场景布局未变；远景棋盘高频不适合判断所有细部拉伸，数据检查与上游C2报告一并使用。不等于GPU draw call/帧率、动态闪烁、手机或游戏引擎验收。

## 回退和复现
baseline/market-C2.glb精确保留上游C2源（SHA256 2acbed3717f3d398533f7a44e0650470ce541dbf81ab8d22153dc73e14840972）。node-mapping-display.json记录activeScene、displayGroup、原node和mesh、原平移、顶点/索引范围。恢复baseline即可恢复所有原层级和字节。
Python3+numpy+Pillow依次运行source/batch-display.py、verify-display.py、topology-display.py；Blender CPU运行source/render.py。batch.py与对应verify.py是13图元研究对照。只支持已验证的静态平移三角场景，不支持动画/蒙皮/共享实例/透排序；失败应停止而非静默丢信息。
