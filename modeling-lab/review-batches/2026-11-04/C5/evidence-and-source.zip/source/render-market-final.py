import bpy,math,json,pathlib,hashlib
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
R=pathlib.Path(__file__).resolve().parents[1]
items=[('market','inputs/market-C2-C4-display.glb'),('storage','inputs/storage-C2.glb')]
reports=[]
for name,path in items:
 if name!='market':continue
 p=R/path;bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
 bpy.ops.import_scene.gltf(filepath=str(p));s=bpy.context.scene;meshes=[o for o in s.objects if o.type=='MESH'];hidden=[o for o in meshes if o.name.startswith('sample_ground') or o.name.startswith(('route_','boundary_','C_continuous_terrain'))];
 for o in hidden:o.hide_render=True
 meshes=[o for o in meshes if o not in hidden];pts=[o.matrix_world@v.co for o in meshes for v in o.data.vertices]
 lo=Vector([min(p[i] for p in pts) for i in range(3)]);hi=Vector([max(p[i] for p in pts) for i in range(3)]);mid=(lo+hi)*.5;size=max(hi-lo)
 bpy.ops.object.camera_add(location=mid+(Vector((.258819,-.965926,2.144507)) if name=='que' else Vector((-1.15,-1.6,1.25)))*size);cam=bpy.context.object;cam.rotation_euler=(mid-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=size*1.6;s.camera=cam
 s.render.resolution_x=1200;s.render.resolution_y=900;s.render.resolution_percentage=100;bpy.context.view_layer.update()
 # Fit projected object bounds to 86% width or height, not fabricated silhouette area.
 proj=[world_to_camera_view(s,cam,p) for p in pts];w=max(p.x for p in proj)-min(p.x for p in proj);h=max(p.y for p in proj)-min(p.y for p in proj);cam.data.ortho_scale*=max(w/(.94 if name=='que' else .86),h/(.94 if name=='que' else .86))
 proj=[world_to_camera_view(s,cam,p) for p in pts];left=min(p.x for p in proj);right=max(p.x for p in proj);bottom=min(p.y for p in proj);top=max(p.y for p in proj)
 # center projected silhouette bbox without modifying asset
 delta=cam.rotation_euler.to_matrix()@Vector(((left+right-1)*cam.data.ortho_scale*.5,(bottom+top-1)*cam.data.ortho_scale*.75*.5,0));cam.location+=delta
 s.render.engine='CYCLES';s.cycles.device='CPU';s.cycles.samples=64;s.cycles.use_denoising=False;s.render.film_transparent=True
 s.world.use_nodes=True;s.world.node_tree.nodes.get('Background').inputs[0].default_value=(.65,.65,.65,1);s.world.node_tree.nodes.get('Background').inputs[1].default_value=.7
 for offset,power in [((-1.5,-2,3),1100),((2,1,2),650)]:
  bpy.ops.object.light_add(type='AREA',location=mid+Vector(offset)*size);l=bpy.context.object;l.data.energy=power*size*size/20;l.data.size=size*1.5;l.rotation_euler=(mid-l.location).to_track_quat('-Z','Y').to_euler()
 s.view_settings.view_transform='AgX';s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGBA';s.render.filepath=str(R/'after'/f'{name}-transparent.png');bpy.ops.render.render(write_still=True)
 reports.append({'name':name,'input':path,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'objects':len(meshes),'dimensions':list(hi-lo),'camera':list(cam.location),'ortho_scale':cam.data.ortho_scale,'view':'three-quarter elevated','renderer':'Blender Cycles CPU 64 samples','resolution':[1200,900],'presentationOnlyHiddenNodes':[o.name for o in hidden]})
 json.dump(reports,open(R/'qa/render-market-final.json','w'),indent=2)
