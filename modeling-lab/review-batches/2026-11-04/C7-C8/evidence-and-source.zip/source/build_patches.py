import json,pathlib,hashlib
R=pathlib.Path(__file__).resolve().parents[1]
base='a63af753e2fa71793a5d4a4ac4ae4a2d99ce437e'; outputs=[]
for file,key in [('notebook-index-snapshot.json','models'),('registry-snapshot.json','entries')]:
 data=json.load(open(R/file));ops=[]
 for i,e in enumerate(data[key]):
  prefix=f'/{key}/{i}';ops += [{'op':'test','path':prefix+'/id','value':e['id']},{'op':'add','path':prefix+'/unit','value':'meter'},{'op':'add','path':prefix+'/unitBasis','value':'glTF coordinate convention only; artistic/design scale is not authenticated real-world size'},{'op':'add','path':prefix+'/intendedRealSize','value':None},{'op':'add','path':prefix+'/intendedRealSizeStatus','value':'unspecified_by_user'}]
 outputs.append({'target':'docs/notebook-index.json'if key=='models'else'docs/model-library/registry.json','baseCommit':base,'snapshotSHA256':hashlib.sha256((R/file).read_bytes()).hexdigest(),'applyOnlyAfterRecheckingCurrentAssetIdsAndFiles':True,'operations':ops})
(R/'codex-metadata-json-patches.json').write_text(json.dumps({'notApplied':True,'noScaling':True,'patches':outputs},ensure_ascii=False,indent=2))
