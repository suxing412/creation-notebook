import json,struct,pathlib,hashlib,numpy as np,collections
ROOT=pathlib.Path(__file__).resolve().parents[2];OUT=ROOT/'uv-repair-pilot'
def load(path):
 b=path.read_bytes();n=struct.unpack_from('<I',b,12)[0];j=json.loads(b[20:20+n]);data=b[28+n:]
 def acc(i):
  a=j['accessors'][i];v=j['bufferViews'][a['bufferView']];dt={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']];k={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];off=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',np.dtype(dt).itemsize*k);return np.ndarray((a['count'],k),dtype=dt,buffer=data,offset=off,strides=(stride,np.dtype(dt).itemsize)).copy()
 out=[]
 def visit(i,parent):
  node=j['nodes'][i];M=np.eye(4)
  if 'matrix'in node:M=np.array(node['matrix']).reshape(4,4).T
  else:
   x,y,z,w=node.get('rotation',[0,0,0,1]);M[:3,:3]=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])@np.diag(node.get('scale',[1,1,1]));M[:3,3]=node.get('translation',[0,0,0])
  M=parent@M
  if 'mesh'in node:
   for p in j['meshes'][node['mesh']]['primitives']:
    pos=acc(p['attributes']['POSITION']);world=(np.c_[pos,np.ones(len(pos))]@M.T)[:,:3];ind=acc(p['indices']).reshape(-1,3).astype(int);uv=acc(p['attributes']['TEXCOORD_0']) if 'TEXCOORD_0'in p['attributes']else None;out.append((node.get('name',''),world[ind],uv[ind]if uv is not None else None))
  for c in node.get('children',[]):visit(c,M)
 for i in j['scenes'][j.get('scene',0)].get('nodes',[]):visit(i,np.eye(4))
 return out

def canonical(tri):
 pts=[tuple(v)for v in np.round(tri,4)];return min(tuple(pts[n:]+pts[:n])for n in range(3))
def summarize(parts):
 rows=[]
 for name,tri,uv in parts:
  r={'node':name,'triangles':len(tri),'hasUV':uv is not None}
  if uv is not None:
   e1=uv[:,1]-uv[:,0];e2=uv[:,2]-uv[:,0];a=(e1[:,0]*e2[:,1]-e1[:,1]*e2[:,0])/2;world=np.linalg.norm(np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]),axis=1)/2
   valid=world>1e-10;r.update(finite=bool(np.isfinite(uv).all()),uvMin=uv.reshape(-1,2).min(0).tolist(),uvMax=uv.reshape(-1,2).max(0).tolist(),zeroUVAreaOnNondegenerate=int(np.sum((abs(a)<1e-10)&valid)),negativeUVOrientation=int(np.sum(a< -1e-10)),positiveUVOrientation=int(np.sum(a>1e-10)),areaDensityRange=[float((abs(a[valid])/world[valid]).min()),float((abs(a[valid])/world[valid]).max())] if valid.any()else None)
  rows.append(r)
 return rows
