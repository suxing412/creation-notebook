from batch import *
def triangles(path):
 j,b=read(path);rows=[];ts=[]
 for n in j['nodes']:
  for p in j['meshes'][n['mesh']]['primitives']:
   ix=arr(j,b,p['indices']).reshape(-1,3);data={a:arr(j,b,k)for a,k in p['attributes'].items()};data['POSITION']+=np.array(n.get('translation',[0,0,0]),dtype=np.float32)
   ts.extend(data['POSITION'][ix])
   for tr in ix:rows.append((p['material'],tuple((a,tuple(data[a][tr].reshape(-1)))for a in sorted(data))))
 return j,np.array(ts),collections.Counter(rows)
import sys
name=sys.argv[1]
src=ROOT/'baseline'/f'{name}-C2.glb';dst=ROOT/'assets'/f'{name}-C2-C4.glb';a,t,x=triangles(src);b,u,y=triangles(dst);assert x==y;assert a['materials']==b['materials'];assert len(b['meshes'])==1 and len(b['meshes'][0]['primitives'])==1
mapping=json.loads((ROOT/'qa'/f'{name}-mapping.json').read_text());report=[]
for s in mapping[0]['sources']:
 z=u[s['indexStart']//3:(s['indexStart']+s['indexCount'])//3];e=collections.Counter();di=collections.Counter();faces=collections.Counter()
 for tri in z:
  q=tuple(tuple(p)for p in tri);faces[min(q[i:]+q[:i]for i in range(3))]+=1
  for v,w in zip(q,q[1:]+q[:1]):e[tuple(sorted((v,w)))]+=1;di[(v,w)]+=1
 r={'node':s['name'],'nonTwoEdges':sum(n!=2 for n in e.values()),'windingErrors':sum(di[(w,v)]!=n for(v,w),n in di.items()),'degenerate':int(sum(np.linalg.norm(np.cross(z[:,1]-z[:,0],z[:,2]-z[:,0]),axis=1)<1e-10)),'duplicateOriented':sum(n-1 for n in faces.values()),'signedVolume':float(np.einsum('ij,ij->i',z[:,0],np.cross(z[:,1],z[:,2])).sum()/6)};report.append(r)
assert all(r['nonTwoEdges']==r['windingErrors']==r['degenerate']==r['duplicateOriented']==0 and r['signedVolume']>0 for r in report)
(ROOT/'qa'/f'{name}-C4-validation.json').write_text(json.dumps({'baselineSHA256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidateSHA256':hashlib.sha256(dst.read_bytes()).hexdigest(),'checkerSHA256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'originalBytes':src.stat().st_size,'candidateBytes':dst.stat().st_size,'primitiveBefore':len(a['meshes']),'primitiveAfter':1,'materials':1,'triangles':len(t),'exactOrientedTrianglesUVNormalMaterialMultiset':x==y,'perOriginalShell':report},indent=2))
print('C4 exact geometry+attributes passed',len(t),src.stat().st_size,dst.stat().st_size)
