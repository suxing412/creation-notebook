import pathlib,json,struct,hashlib,copy,numpy as np,collections
P=pathlib.Path(__file__).resolve().parents[1];src=P/'originals/market-prior-C2.glb';b=src.read_bytes();n=struct.unpack_from('<I',b,12)[0];j=json.loads(b[20:20+n]);original=copy.deepcopy(j);data=bytearray(b[28+n:])
def arr(i):
 a=j['accessors'][i];v=j['bufferViews'][a['bufferView']];dt={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']];k={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];return np.ndarray((a['count'],k),dtype=dt,buffer=data,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',np.dtype(dt).itemsize*k),np.dtype(dt).itemsize)).copy()
def append(a,typ,component):
 while len(data)%4:data.append(0)
 offset=len(data);data.extend(a.tobytes());vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':offset,'byteLength':a.nbytes});ai=len(j['accessors']);j['accessors'].append({'bufferView':vi,'componentType':component,'count':len(a),'type':typ,'min':a.min(0).tolist(),'max':a.max(0).tolist()});return ai
used={n['mesh']for n in j['nodes']if'mesh'in n};report=[]
for mi,m in enumerate(j['meshes']):
 if mi in used:continue
 for pi,p in enumerate(m['primitives']):
  idx=arr(p['indices']).ravel().astype(int);pos=arr(p['attributes']['POSITION']);ts=pos[idx].reshape(-1,3,3);uv=[]
  for t in ts:
   nor=np.cross(t[1]-t[0],t[2]-t[0]);axis=int(np.argmax(abs(nor)));u,v=[(1,2),(2,0),(0,1)][axis];sgn=1 if nor[axis]>=0 else -1;uv.extend(np.c_[t[:,u]*sgn,t[:,v]])
  attrs={k:(arr(a),copy.deepcopy(j['accessors'][a]))for k,a in p['attributes'].items()if k!='TEXCOORD_0'}
  for k,(a,meta)in attrs.items():p['attributes'][k]=append(a[idx],meta['type'],meta['componentType'])
  q=np.array(uv,dtype='<f4');p['attributes']['TEXCOORD_0']=append(q,'VEC2',5126);p['indices']=append(np.arange(len(idx),dtype='<u4').reshape(-1,1),'SCALAR',5125);assert np.array_equal(arr(p['attributes']['POSITION']),ts.reshape(-1,3));report.append({'meshIndex':mi,'primitiveIndex':pi,'name':m.get('name'),'triangles':len(ts),'projectionSpace':'mesh-local coordinates; 1UV/unit; assumes unscaled scene-meter units on later identity instantiation','renderedInCurrentScene':False})
rows=[]
for mi,m in enumerate(j['meshes']):
 for pi,p in enumerate(m['primitives']):
  if 'TEXCOORD_0'not in p['attributes']:rows.append({'meshIndex':mi,'missingUV':True});continue
  ind=arr(p['indices']).ravel().astype(int);t=arr(p['attributes']['POSITION'])[ind].reshape(-1,3,3);q=arr(p['attributes']['TEXCOORD_0'])[ind].reshape(-1,3,2);e1=q[:,1]-q[:,0];e2=q[:,2]-q[:,0];area=abs(e1[:,0]*e2[:,1]-e1[:,1]*e2[:,0]);geom=np.linalg.norm(np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]),axis=1);rows.append({'meshIndex':mi,'missingUV':False,'finite':bool(np.isfinite(q).all()),'zeroUVNondegenerate':int(np.sum((area<1e-10)&(geom>2e-10))),'referenced':mi in used})
assert not any(x['missingUV']or not x['finite']or x['zeroUVNondegenerate']for x in rows)
j['buffers'][0]['byteLength']=len(data);js=json.dumps(j,separators=(',',':')).encode();js+=b' '*((-len(js))%4);data+=b'\0'*((-len(data))%4);raw=struct.pack('<III',0x46546c67,2,12+8+len(js)+8+len(data))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(data),0x004e4942)+data;(P/'assets/market-A-N2-C2-including-orphans.glb').write_bytes(raw)
result={'review':'C2','originalSourceSHA256':hashlib.sha256(b).hexdigest(),'outputSHA256':hashlib.sha256(raw).hexdigest(),'storedMeshes':len(j['meshes']),'referencedMeshes':len(used),'patchedOrphanMeshes':len(report),'nodesUnchanged':j['nodes']==original['nodes'],'materialsUnchanged':j['materials']==original['materials'],'activeMeshJSONUnchanged':all(j['meshes'][i]==original['meshes'][i]for i in used),'missingUVPrimitives':0,'zeroUVNondegenerate':0,'orphans':report,'allPrimitiveChecks':rows};json.dump(result,open(P/'qa/market-orphan-validation.json','w'),indent=2);print({k:v for k,v in result.items()if k not in ['orphans','allPrimitiveChecks']})
