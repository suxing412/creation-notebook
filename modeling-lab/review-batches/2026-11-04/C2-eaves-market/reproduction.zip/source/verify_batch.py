import pathlib,json,numpy as np,hashlib,collections
P=pathlib.Path(__file__).resolve().parents[1];ns={'__file__':str(P/'source/readglb.py')};exec((P/'source/readglb.py').read_text(),ns);load=ns['load']
def canon(t):
 v=[tuple(p)for p in t];return min(tuple(v[n:]+v[:n])for n in range(3))
rows=[]
for asset in json.load(open(P/'sources.json')):
 name=asset['id'];r=json.load(open(P/'qa'/f'{name}-C2-validation.json'));before=load(P/asset['original']);after=load(P/'assets'/f'{name}-C2.glb');same=collections.Counter(canon(t)for _,ts,_ in before for t in ts)==collections.Counter(canon(t)for _,ts,_ in after for t in ts);uv=np.concatenate([u.reshape(-1,2)for _,_,u in after]);duplicates=sum(n-1 for n in collections.Counter(canon(np.round(t,6))for _,_,ts in after for t in ts).values()if n>1)
 rows.append({**asset,'output':f'assets/{name}-C2.glb','outputSHA256':r['outputSHA256'],'outputBytes':(P/'assets'/f'{name}-C2.glb').stat().st_size,'triangles':sum(x['triangles']for x in r['after']),'primitives':len(r['after']),'exactWorldOrientedGeometry':same,'materialsUnchanged':r['materialJSONUnchanged'],'allUVFinite':all(x['finite']for x in r['after']),'nondegenerateFacesZeroUV':sum(x['zeroUVAreaOnNondegenerate']for x in r['after']),'maxCoordinateErrorMeters':max(x['maxUVCoordinateErrorMeters']for x in r['checks']),'maxProjectedEdgeErrorMeters':max(x['maxProjectedEdgeScaleErrorMeters']for x in r['checks']),'uvMin':uv.min(0).tolist(),'uvMax':uv.max(0).tolist(),'exactUVTriangleDuplicatesAt6Decimals':duplicates,'uvOverlapIntentional':True})
assert all(x['exactWorldOrientedGeometry'] and x['materialsUnchanged'] and x['allUVFinite'] and x['nondegenerateFacesZeroUV']==0 for x in rows)
json.dump(rows,open(P/'qa/batch-summary.json','w'),indent=2);print('Validated',len(rows),'files,',sum(x['triangles']for x in rows),'triangle records; maximum coordinate error',max(x['maxCoordinateErrorMeters']for x in rows),'maximum projected edge error',max(x['maxProjectedEdgeErrorMeters']for x in rows))
