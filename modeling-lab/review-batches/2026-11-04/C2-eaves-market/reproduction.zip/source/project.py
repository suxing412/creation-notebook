import pathlib,json,struct,hashlib,copy,numpy as np
ROOT=pathlib.Path(__file__).resolve().parents[2];OUT=ROOT/'C2-eaves-market-v6'
# Use shared independent decoder definitions; no inherited asset metrics.
import sys
asset=sys.argv[1]
src=OUT/'originals'/f'{asset}.glb'
ns={'__file__':str(OUT/'source/readglb.py')};exec((OUT/'source/readglb.py').read_text().split('res=[]')[0],ns);load=ns['load'];parts=load(src)
b=src.read_bytes();n=struct.unpack_from('<I',b,12)[0];j=json.loads(b[20:20+n]);data=bytearray(b[28+n:]);report=[]
def arr(i):
 a=j['accessors'][i];v=j['bufferViews'][a['bufferView']];dt={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']];k={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];return np.ndarray((a['count'],k),dtype=dt,buffer=data,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',np.dtype(dt).itemsize*k),np.dtype(dt).itemsize)).copy()
def append(a,typ,component):
 while len(data)%4:data.append(0)
 offset=len(data);data.extend(a.tobytes());vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':offset,'byteLength':a.nbytes});ai=len(j['accessors']);j['accessors'].append({'bufferView':vi,'componentType':component,'count':len(a),'type':typ,'min':a.min(0).tolist(),'max':a.max(0).tolist()});return ai
for node in j['nodes']:
 if 'mesh'not in node:continue
 for p in j['meshes'][node['mesh']]['primitives']:
  name=node['name']
  _,ts,old=next(x for x in parts if x[0]==name);uv=[];dirs=[];error=0
  for tr in ts:
   normal=np.cross(tr[1]-tr[0],tr[2]-tr[0]);axis=int(np.argmax(abs(normal)));sign=1 if normal[axis]>=0 else -1
   # Right-handed plane basis for each normal axis, then side sign on U.
   u,v=[(1,2),(2,0),(0,1)][axis];q=np.c_[tr[:,u]*sign,tr[:,v]];uv.extend(q);dirs.append([axis,sign,u,v])
  indices=arr(p['indices']).ravel().astype(int);attrs={k:(arr(i),copy.deepcopy(j['accessors'][i]))for k,i in p['attributes'].items() if k!='TEXCOORD_0'}
  for k,(a,m)in attrs.items():p['attributes'][k]=append(a[indices],m['type'],m['componentType'])
  uv=np.array(uv,dtype='<f4');p['attributes']['TEXCOORD_0']=append(uv,'VEC2',5126);p['indices']=append(np.arange(len(indices),dtype='<u4').reshape(-1,1),'SCALAR',5125)
  report.append({'node':name,'triangles':len(ts),'directions':dirs,'method':'Signed dominant-normal world-axis box projection. UV=(sign * world[Uaxis], world[Vaxis]); world scene meter = 1 UV unit; no normalization or packing.','priorUV':old is not None})
j['buffers'][0]['byteLength']=len(data);js=json.dumps(j,separators=(',',':')).encode();js+=b' '*((-len(js))%4);data+=b'\0'*((-len(data))%4);raw=struct.pack('<III',0x46546c67,2,12+8+len(js)+8+len(data))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(data),0x004e4942)+data
(OUT/'assets'/f'{asset}-C2.glb').write_bytes(raw);json.dump(report,open(OUT/'qa'/f'{asset}-projection-map.json','w'),indent=2)
# Independent final-accessor validation against meter coordinate projection.
after=load(OUT/'assets'/f'{asset}-C2.glb');checks=[]
for r in report:
 _,ts,uv=next(x for x in after if x[0]==r['node']);maxerr=0;maxedge=0
 for t,q,d in zip(ts,uv,r['directions']):
  axis,sign,u,v=d;expected=np.c_[t[:,u]*sign,t[:,v]];maxerr=max(maxerr,float(abs(q-expected).max()));maxedge=max(maxedge,float(abs((q[1:]-q[0])-(expected[1:]-expected[0])).max()))
 checks.append({'node':r['node'],'maxUVCoordinateErrorMeters':maxerr,'maxProjectedEdgeScaleErrorMeters':maxedge})
canon=ns['canonical'];from collections import Counter
geo=Counter(canon(t)for _,ts,_ in parts for t in ts)==Counter(canon(t)for _,ts,_ in after for t in ts)
report={'review':'C2','scope':asset+' all mesh primitives','inputSHA256':hashlib.sha256(b).hexdigest(),'outputSHA256':hashlib.sha256(raw).hexdigest(),'geometryWorldOrientedTrianglesMatch1e4':geo,'materialJSONUnchanged':j.get('materials')==json.loads(b[20:20+n]).get('materials'),'checks':checks,'before':ns['summarize'](parts),'after':ns['summarize'](after)}
json.dump(report,open(OUT/'qa'/f'{asset}-C2-validation.json','w'),indent=2);print('geometry',geo,'maxerror',checks)
