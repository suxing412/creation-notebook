from PIL import Image,ImageDraw
from pathlib import Path
import json,hashlib,zipfile
p=Path(__file__).resolve().parents[1];root=p.parent;c=Image.new('RGB',(1440,840),'#eeeae3');d=ImageDraw.Draw(c)
for row,variant in enumerate(['A','B']):
 for lod in range(3):
  name=f'eaves-{variant}-LOD{lod}';f=p/'qa'/f'{name}-final-checker-1-CPU.png';c.paste(Image.open(f).convert('RGB'),(lod*480,row*420));d.text((lod*480+8,row*420+403),name+' | 1m box UV | CPU',fill='black')
c.save(p/'qa/C2-eaves-six-version-comparison-CPU.png')
sources=json.load(open(p/'sources.json'));files=[p/'README.md',p/'sources.json',p/'qa/batch-summary.json']+list((p/'source').glob('*.py'))+list((p/'qa').glob('*.png'))
for x in sources:
 n=x['id'];files += [p/x['original'],p/'assets'/f'{n}-C2.glb',p/'qa'/f'{n}-C2-validation.json',p/'qa'/f'{n}-projection-map.json']
files += [p/'assets/market-A-N2-C2-including-orphans.glb',p/'originals/market-prior-C2.glb',p/'originals/market-public-original.glb',p/'qa/market-orphan-validation.json',p/'qa/market-full-file-readback.json']
m={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest()for f in files};(p/'SHA256.json').write_text(json.dumps(m,indent=2));files.append(p/'SHA256.json')
with zipfile.ZipFile(root/'C2-eaves-market-v6.zip','w',zipfile.ZIP_DEFLATED)as z:
 for f in files:z.write(f,str(f.relative_to(root)))
with zipfile.ZipFile(root/'C2-eaves-market-v6.zip')as z:
 assert z.testzip()is None
 for f,h in m.items():assert hashlib.sha256(z.read(f)).hexdigest()==h
print(len(files),(root/'C2-eaves-market-v6.zip').stat().st_size)
