import pathlib,json,struct,numpy as np,collections,hashlib
P=pathlib.Path(__file__).resolve().parents[1]
def decode(p):
 b=p.read_bytes();n=struct.unpack_from('<I',b,12)[0];j=json.loads(b[20:20+n]);data=b[28+n:]
 def acc(i):
  a=j['accessors'][i];v=j['bufferViews'][a['bufferView']];dt={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']];k={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];return np.ndarray((a['count'],k),dtype=dt,buffer=data,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',np.dtype(dt).itemsize*k),np.dtype(dt).itemsize)).copy()
 out=[]
 for mi,m in enumerate(j['meshes']):
  for pi,p in enumerate(m['primitives']):
   idx=acc(p['indices']).ravel().astype(int);t=acc(p['attributes']['POSITION'])[idx].reshape(-1,3,3);q=acc(p['attributes']['TEXCOORD_0'])[idx].reshape(-1,3,2) if'TEXCOORD_0'in p['attributes']else None;out.append((mi,pi,t,q))
 return b,j,out
before,j0,a=decode(P/'originals/market-prior-C2.glb');after,j1,b=decode(P/'assets/market-A-N2-C2-including-orphans.glb');assert len(a)==len(b)
def canon(t):
 v=[tuple(x)for x in t];return min(tuple(v[n:]+v[:n])for n in range(3))
checks=[]
for (mi,pi,t,u),(mj,pj,s,q)in zip(a,b):
 assert(mi,pi)==(mj,pj);same=collections.Counter(canon(x)for x in t)==collections.Counter(canon(x)for x in s);assert same and q is not None
 e1=q[:,1]-q[:,0];e2=q[:,2]-q[:,0];area=abs(e1[:,0]*e2[:,1]-e1[:,1]*e2[:,0]);geom=np.linalg.norm(np.cross(s[:,1]-s[:,0],s[:,2]-s[:,0]),axis=1);zero=int(np.sum((area<1e-10)&(geom>2e-10)));assert zero==0 and np.isfinite(q).all();checks.append({'meshIndex':mi,'primitiveIndex':pi,'exactLocalGeometryUnchanged':same,'UVFinite':True,'zeroUVNondegenerate':zero})
r={'review':'C2','outputSHA256':hashlib.sha256(after).hexdigest(),'actualStoredFileReadback':True,'storedPrimitives':len(checks),'missingUV':0,'zeroUVNondegenerate':0,'nodesUnchanged':j0['nodes']==j1['nodes'],'materialsUnchanged':j0['materials']==j1['materials'],'checks':checks};json.dump(r,open(P/'qa/market-full-file-readback.json','w'),indent=2);print(len(checks),'all stored primitive geometry exact, UV finite/nonzero')
