import bpy,sys,json,math,pathlib,hashlib
from mathutils import Vector
ROOT=pathlib.Path(__file__).resolve().parents[2]; OUT=ROOT/'C2-courtyard-family-v4'
report=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def setup_render(meshes):
 s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.device='CPU';s.cycles.samples=16;s.cycles.use_denoising=False;s.render.resolution_x=480;s.render.resolution_y=400;s.render.resolution_percentage=100;s.world.color=(.45,.45,.45)
 points=[o.matrix_world@Vector(c) for o in meshes for c in o.bound_box];lo=Vector([min(p[i]for p in points)for i in range(3)]);hi=Vector([max(p[i]for p in points)for i in range(3)]);mid=(lo+hi)/2;sz=max(hi-lo)
 bpy.ops.object.camera_add(location=mid+Vector((1.1,-1.3,1.2))*sz);c=bpy.context.object;c.rotation_euler=(mid-c.location).to_track_quat('-Z','Y').to_euler();c.data.type='ORTHO';c.data.ortho_scale=sz*1.6;s.camera=c
 for offset,power in [((1,-1,2),1500),((-1,.5,1.2),800)]:
  bpy.ops.object.light_add(type='AREA',location=mid+Vector(offset)*sz);l=bpy.context.object;l.data.energy=power*sz*sz/25;l.data.shape='DISK';l.data.size=sz
 s.view_settings.view_transform='Standard';s.render.image_settings.file_format='PNG'

for name in [x['id'] for x in json.load(open(OUT/'sources.json'))]:
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);bpy.ops.import_scene.gltf(filepath=str(OUT/'assets'/f'{name}-C2.glb'));mesh=[o for o in bpy.context.scene.objects if o.type=='MESH'];setup_render(mesh)
 mat=bpy.data.materials.new('validation_checker');mat.use_nodes=True;n=mat.node_tree.nodes;l=mat.node_tree.links;p=n.get('Principled BSDF');t=n.new('ShaderNodeTexChecker');t.inputs['Color1'].default_value=(.08,.12,.16,1);t.inputs['Color2'].default_value=(.85,.7,.38,1);coords=n.new('ShaderNodeTexCoord');l.new(coords.outputs['UV'],t.inputs['Vector']);l.new(t.outputs['Color'],p.inputs['Base Color']);p.inputs['Roughness'].default_value=.8
 patched={o.name for o in mesh}
 for o in mesh:
  if o.name in patched:o.data.materials.clear();o.data.materials.append(mat)
 for s in [1]:
  t.inputs['Scale'].default_value=s;bpy.context.scene.render.filepath=str(OUT/'qa'/f'{name}-final-checker-{s}-CPU.png');bpy.ops.render.render(write_still=True)
