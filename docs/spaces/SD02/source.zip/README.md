# SD02 岔径·望场

可探索建筑空间原型，部署目标 `spaces/SD02/`。不同年代地域建筑的当代比较场，不是历史聚落复原。默认是全视口三维空间，静态图文只在用户选择、无脚本、无GL或小视口时出现。

## 用户在空间中做什么
道路前固定低位抵达（宽屏辨高仓与低院；窄屏高仓为主） → 选左/右支路 → 固定低位看梯廊或门洞 → 抬升读全场或院内层次 → 回望/回岔口。全场俯瞰由用户主动选择，不是默认远看一块地图。低位只允许左右有限转向，非人形自由漫步。仓低位有意裁切屋顶，是梯廊近观而非完整模型视图；全景始终可恢复。高位可旋转、平移和缩放。

## 原件与变换
- `dist/assets/granary-A.glb` 保持012冻结字节；Three Y-up平移[-13,0,-5]，scale1。
- `dist/assets/courtyard-A.glb` 保持013 v05冻结字节；平移[10,0,-6]，scale1。
- 原生可编辑A款在 `source/inputs-clean/`，来自已确认清理版源包；原包SHA、GLB SHA、机构原件链接与三维变换见 `source/input-map.json`。
- 原创新地形单独 `environment.blend/.glb`；连续地面在原地台处作精确浅槽，不改原模型或铺入其体积。
- 路线和导航圈是当代观看组织，不是考古证据、古代构件或角色导航网格。

## 复现
Node 24，Blender 4.3.2，固定Three r180包内依赖。

```sh
node source/test-navigation.mjs
node source/test-app.mjs
node --loader ./source/three-loader.mjs source/check-runtime-assets.mjs
python source/verify-release.py
blender -b --python source/build-environment.py
blender -b --python source/render-environment-check.py -- --final
```

环境生成与渲染都不需外部AI或账号。最终CPU Cycles 48采样图仅为静态证据；PNG清理例程在渲染脚本内，保留IDAT不变并移除文本元数据。脚本用相对目录。

## 验证范围
- 环境闭合拓扑、源地台精确矩形假设、局部承托/侧边接触、实际GLB有向三角一致。
- 高位投影+safe area、有限镜头尺寸与转场采样；固定低位近面/下降段有限净空。
- 真应用代码/真Three数学在明确假DOM、假渲染器的生命周期检查：取消迟到、快选路、回退、重试、释放、上下文丢失。
- 受支持原生云预览与云浏览器：桌面/窄屏/极小视口/无脚本备用、帮助焦点与重试。云GL Disabled，没有改安全设置。
- 尚未验证：主体验GPU渲染、实际触屏、动态闪烁、帧率、连续全域碰撞、所有输入参数、SLG万点位或理解效果。

CPU概念高位图与实际运行时镜头图分开命名。离线光照不等同实时Three着色。公开状态由唯一发布writer处理；本包不是已发布证明。

## 有限复用证据
`reuse-test/README.md`记录013 B替换的真实几何迁移：旧A孔槽实际交叠11.5单位体积，按B真实包络/门轴重算后限定检查通过；同生成器默认A重建GLB逐字节不变。仅两个离散组合，不宣称任意模型通用。
