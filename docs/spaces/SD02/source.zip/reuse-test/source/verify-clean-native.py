"""Verify retained clean B native bytes; optional archive path re-materializes exact member."""
import sys,zipfile,json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1];p=R/'source/inputs-clean/courtyard-B.blend';expected='dda805c514d3baff87a0b149fa75f2dc0807be326d3ea83d092beacf81a14435'
if len(sys.argv)>1:p.write_bytes(zipfile.ZipFile(sys.argv[1]).read('study-013/models/whitebox-B.blend'))
blob=p.read_bytes();assert hashlib.sha256(blob).hexdigest()==expected
assert not any(s in blob for s in [b'/home/agent',b'/workspace/',b'/tmp/'])
print('Clean original B native hash and private-path marker scan passed')
