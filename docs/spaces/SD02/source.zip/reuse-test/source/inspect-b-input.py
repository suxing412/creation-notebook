import bpy,json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1];p=R/'dist/assets/courtyard-B.glb';bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);bpy.ops.import_scene.gltf(filepath=str(p));out=[]
for o in bpy.context.scene.objects:
 if o.type=='MESH' and (o.name in ['C_ground','C_arrival','C_path_turn','C_path_to_door'] or o.name.startswith('B_gate_jamb')):
  vs=[o.matrix_world@v.co for v in o.data.vertices];ps=[[v.x+10,v.z,-v.y-6] for v in vs];out.append({'object':o.name,'bounds':[[min(p[k] for p in ps),max(p[k] for p in ps)] for k in range(3)]})
(R/'qa/b-actual-nodes.json').write_text(json.dumps({'input_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'nodes':out},indent=2))
