"""Small CPU camera evidence only, no browser/GPU claim. No source model mutation."""
import bpy,json,math,hashlib,struct,zlib,sys
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
reuse='--reuse-root' in sys.argv
R=Path(sys.argv[sys.argv.index('--reuse-root')+1]).resolve() if reuse else Path(__file__).resolve().parents[1];Q=R/'qa';A=R/'dist/assets'
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
inputs=[('environment.glb',(0,0,0)),('granary-A.glb',(-13,5,0)),('courtyard-A.glb',(10,6,0))]
if reuse:
 layout=json.loads((R/'source/environment-layout.json').read_text());inputs=[('environment.glb',(0,0,0))]+[(v['file'],(v['position'][0],-v['position'][2],v['position'][1])) for v in layout['models']]
for file,off in inputs:
 before=set(bpy.context.scene.objects);bpy.ops.import_scene.gltf(filepath=str(A/file))
 for o in set(bpy.context.scene.objects)-before:
  if o.parent is None:o.location+=Vector(off)
bpy.context.view_layer.update();vs=[];fs=[]
for o in bpy.context.scene.objects:
 if o.type!='MESH':continue
 n=len(vs);vs.extend(o.matrix_world@v.co for v in o.data.vertices);fs.extend([n+i for i in p.vertices] for p in o.data.polygons)
bvh=BVHTree.FromPolygons(vs,fs)
def conv(p):return Vector((p[0],-p[2],p[1]))
def nearest(p):
 v,n,i,d=bvh.find_nearest(p);return d
bpy.ops.object.camera_add();cam=bpy.context.object;sc=bpy.context.scene;sc.camera=cam;cam.data.type='PERSP';cam.data.sensor_fit='VERTICAL';cam.data.sensor_height=24;cam.data.lens=24/(2*math.tan(math.radians(42)/2));cam.data.clip_start=.1;cam.data.clip_end=250
bpy.ops.object.light_add(type='AREA',location=(-15,-15,30));bpy.context.object.data.energy=12000;bpy.context.object.data.size=20
sc.render.engine='CYCLES';sc.cycles.device='CPU';sc.cycles.samples=48;sc.cycles.seed=0;sc.cycles.use_denoising=False;sc.world.use_nodes=True;sc.world.node_tree.nodes['Background'].inputs['Color'].default_value=(.74,.78,.75,1);sc.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.8;sc.view_settings.view_transform='Standard';sc.render.resolution_x=600;sc.render.resolution_y=400;sc.render.resolution_percentage=100;sc.render.image_settings.file_format='PNG'
views=[('granary-low',[-8.2,2.4,5.2],[-12.2,1.65,-2]),('courtyard-low',[10,1.45,5.8],[10,1.1,-2]),('granary-high',[-4,14,10],[-13,2,-3]),('courtyard-high',[21,16,13],[10,1,-5])]

# Fit overview to full landscape box at the same directional cue as entry UI.
target=Vector((0,1,1));direction=Vector((.32,.7,1)).normalized();right=Vector((direction.z,0,-direction.x)).normalized();up=direction.cross(right);tv=math.tan(math.radians(42)/2);distance=1
for x in [-25,25]:
 for y in [-1,6.6]:
  for z in [-23,24]:
   delta=Vector((x,y,z))-target;distance=max(distance,delta.dot(direction)+1.10*abs(delta.dot(right))/(tv*4/3),delta.dot(direction)+1.10*abs(delta.dot(up))/tv)
views.append(('environment-overview',list(target+direction*distance),list(target)))
entry_trial='--entry-trial' in sys.argv
entry_only='--entry-only' in sys.argv or entry_trial
final='--final' in sys.argv
runtime='--runtime' in sys.argv or final or entry_only
if runtime:
 contract=json.loads((Q/'runtime-camera-presets.json').read_text());views=[('runtime-'+v['id'],v['position'],v['target']) for v in contract['views'] if (v['id']=='entry' and not v['raised']) or (v['id'] in ['granary','courtyard'] and v['raised'])]
if entry_only:views=[('runtime-entry',v['position'],v['target']) for v in contract['views'] if v['id']=='entry' and not v['raised']]
if entry_trial:views=[('entry-low-back' if '--entry-back' in sys.argv else 'entry-low-trial',[1.5,3.4,29 if '--entry-back' in sys.argv else 22],[0,2.6,-2])]
if '--entry-narrow' in sys.argv:views=[('entry-low-narrow',[1.5,3.4,29],[-10,2.6,-1])]
if final:
 views += [('granary-low',[-8.2,2.4,5.2],[-12.2,1.65,-2]),('courtyard-low',[10,1.45,5.8],[10,1.1,-2]),('entry-low-narrow',[1.5,3.4,29],[-10,2.6,-1])]
if reuse:views=[('reuse-b-high',[21,17,15],[10,1,-5]),('reuse-b-low',[8.9,1.45,5.8],[8.9,1.1,-3])]
out=[]
def chunks(blob):
 pos=8
 while pos<len(blob):
  n=int.from_bytes(blob[pos:pos+4],'big');yield blob[pos+4:pos+8],blob[pos:pos+n+12];pos+=n+12
for name,pos,target in views:
 sc.render.resolution_x=390 if name=='entry-low-narrow' else 750 if runtime else 800 if name=='environment-overview' else 600;sc.render.resolution_y=844 if name=='entry-low-narrow' else 500 if runtime else 600 if name=='environment-overview' else 400
 if '--entry-narrow' in sys.argv:sc.render.resolution_x=390;sc.render.resolution_y=844
 cam.location=conv(pos);cam.rotation_euler=(conv(target)-cam.location).to_track_quat('-Z','Y').to_euler();bpy.context.view_layer.update()
 f=.1*math.tan(math.radians(42)/2);corners=[cam.matrix_world@Vector((x*f*(sc.render.resolution_x/sc.render.resolution_y),y*f,-.1)) for x in [-1,1] for y in [-1,1]]
 distances=[nearest(v) for v in corners]; descent=[]
 if name.endswith('low'):
  for k in range(107):
   h=12+(pos[1]-12)*k/106;descent.append(nearest(conv([pos[0],h,pos[2]])))
 path=Q/(name+'.png');sc.render.filepath=str(path);bpy.ops.render.render(write_still=True)
 blob=path.read_bytes();before=b''.join(raw for typ,raw in chunks(blob) if typ==b'IDAT');clean=blob[:8]+b''.join(raw for typ,raw in chunks(blob) if typ not in [b'tEXt',b'zTXt',b'iTXt']);path.write_bytes(clean);after=b''.join(raw for typ,raw in chunks(clean) if typ==b'IDAT');assert before==after;assert not any(x in clean for x in [b'/workspace/',b'/home/agent',b'/tmp/'])
 out.append({'view':name,'three_position':pos,'three_target':target,'fov_vertical':42,'near':.1,'cpu_samples':48,'resolution':[sc.render.resolution_x,sc.render.resolution_y],'environment_sha256':hashlib.sha256((A/'environment.glb').read_bytes()).hexdigest(),'camera_nearest_geometry':nearest(cam.location),'near_four_corner_distances':distances,'descent_samples':len(descent),'descent_min_clearance':min(descent) if descent else None,'clearance_radius_test':.15,'clearance_pass':not descent or min(descent)>.15,'png_metadata_removed_idat_identical':before==after,'png_sha256':hashlib.sha256(clean).hexdigest(),'scope':'finite samples and corner distances, no continuous collision or GPU navigation proof'})
report={'input_camera_contract_sha256':hashlib.sha256((Q/'runtime-camera-presets.json').read_bytes()).hexdigest(),'scope':('Requested trial camera; not runtime binding.' if entry_trial else 'Exact fixed runtime cameras; 1.5 aspect except explicit 390x844 narrow entry. CPU rendering without HTML overlays, not GPU or live-navigation equivalence.'),'views':out} if runtime else out
(Q/(('environment-entry-narrow.json' if '--entry-narrow' in sys.argv else 'environment-entry-back.json' if '--entry-back' in sys.argv else 'environment-entry-trial.json') if entry_trial else 'environment-entry-camera.json' if entry_only else 'environment-final-cameras.json' if final else 'environment-runtime-camera.json' if runtime else 'environment-low-camera.json')).write_text(json.dumps(report,indent=2));print(json.dumps(report))
