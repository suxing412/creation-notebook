"""Read-only public release audit. PNG structure and pixel checks are not GPU tests."""
from pathlib import Path
import json,hashlib,struct,zlib
R=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def png(p):
 b=p.read_bytes();assert b[:8]==b'\x89PNG\r\n\x1a\n';i=8;chunks=[];idat=b''
 while i<len(b):
  n=int.from_bytes(b[i:i+4],'big');typ=b[i+4:i+8];data=b[i+8:i+8+n];crc=int.from_bytes(b[i+8+n:i+12+n],'big');assert zlib.crc32(typ+data)&0xffffffff==crc
  chunks.append(typ.decode());assert typ not in [b'tEXt',b'zTXt',b'iTXt']
  if typ==b'IDAT':idat+=data
  i+=12+n
 assert i==len(b);return{'file':str(p.relative_to(R)),'sha256':sha(p),'chunks':chunks,'idat_sha256':hashlib.sha256(idat).hexdigest(),'no_text_metadata':True}
files=[];images=[]
for p in (R/'dist').rglob('*'):
 if not p.is_file():continue
 assert not p.name.startswith('_'),'private harness in dist'
 if p.name=='source.zip':continue
 data=p.read_bytes();assert all(x not in data for x in [b'/workspace/scratch/',b'/home/agent/',b'libfile_',b'sig=']),str(p)
 files.append({'file':str(p.relative_to(R)),'sha256':sha(p),'bytes':len(data)})
 if p.suffix=='.png':images.append(png(p))
for p in R.rglob('*.blend'):assert all(x not in p.read_bytes() for x in [b'/workspace/',b'/home/agent',b'/tmp/'])
for p in R.rglob('*.png'):png(p)
expected={'granary-A.glb':'8c340f35b5283d84393f4a3b8ee7e22e372f1aae58d67dbc3020e808a1f599bf','courtyard-A.glb':'f7dc654269259ec87f03010d5ea3fe7853cf92a44d2b91287397af80532c5b9b'}
for name,h in expected.items():assert sha(R/'dist/assets'/name)==h
out={'passed':True,'scope':'byte/privacy/PNG-CRC-text-chunk and frozen-asset audit, not GPU/material equivalence','files':files,'public_pngs':images,'unchanged_source_glbs':expected};(R/'qa/release-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps({'passed':True,'files':len(files),'pngs':len(images)}))
