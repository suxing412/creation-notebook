"""Produce public editable source and private Library-ready complete package."""
from pathlib import Path
import zipfile,hashlib,json,re
R=Path(__file__).resolve().parents[1]
def accepted(p):
 rel=p.relative_to(R)
 return p.is_file() and not any(x.startswith('private-') or x=='__pycache__' for x in rel.parts) and not p.name.startswith('_') and p.suffix not in ['.blend1','.pyc','.zip'] and p.name not in ['delivery.json','FILE-MANIFEST.json','archive-audit.json']
files=sorted(p for p in R.rglob('*') if accepted(p))
for p in files:
 b=p.read_bytes()
 assert not re.search(rb'/workspace/scratch/[a-z0-9]',b),str(p)
 assert not re.search(rb'libfile_[a-f0-9]{16,}',b),str(p)
 assert not re.search(rb'https?://[^\s"\x00]+[?&](?:sig|token)=',b),str(p)
manifest=[{'file':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in files]
(R/'FILE-MANIFEST.json').write_text(json.dumps(manifest,indent=2))
files=sorted(p for p in R.rglob('*') if accepted(p))+[R/'FILE-MANIFEST.json']
source=R/'dist/source.zip'
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.relative_to(R))
with zipfile.ZipFile(source) as z:assert z.testzip() is None
complete=R.parent/'sd02-spatial-field-complete-v1.zip'
with zipfile.ZipFile(complete,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[source]:z.write(p,Path('space-design-02')/p.relative_to(R))
with zipfile.ZipFile(complete) as z:assert z.testzip() is None
out={'stage':'spatial prototype, not GPU accepted','public_directory':'space-design-02/dist','publish_destination':'spaces/SD02/','source_zip_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'complete_file':complete.name,'complete_sha256':hashlib.sha256(complete.read_bytes()).hexdigest(),'complete_bytes':complete.stat().st_size,'source_files':len(files),'public_source_no_private_identity':True}
(R/'delivery.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
