"""Bind failure/revision evidence for a single actual courtyard-B migration."""
import bpy,json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1];T=R/'reuse-test';Q=T/'qa'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def clip(poly,axis,bound,keep):
 out=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  da=(a[axis]-bound)*keep;db=(b[axis]-bound)*keep;ia=da>=0;ib=db>=0
  if ia:out.append(a)
  if ia!=ib:
   t=da/(da-db);out.append([a[k]+t*(b[k]-a[k]) for k in range(3)])
 return out
old=R/'dist/assets/environment.glb';bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);bpy.ops.import_scene.gltf(filepath=str(old));triangles=[]
for o in bpy.context.scene.objects:
 if o.type!='MESH':continue
 o.data.calc_loop_triangles()
 for tri in o.data.loop_triangles:
  ps=[o.matrix_world@o.data.vertices[i].co for i in tri.vertices];triangles.append([[v.x,v.z,-v.y] for v in ps])
regions=[('B left extension',[2,3,-13,3]),('B right extension',[17,18,-13,3]),('B rear extension',[3,17,-13,-12])];measure=[]
for label,(x0,x1,z0,z1) in regions:
 volume=0;surface_area=0;count=0
 for t in triangles:
  ps=t
  for axis,bound,keep in [(0,x0,1),(0,x1,-1),(2,z0,1),(2,z1,-1),(1,0,1),(1,.25,-1)]:ps=clip(ps,axis,bound,keep)
  if len(ps)<3:continue
  for k in range(1,len(ps)-1):
   a,b,c=ps[0],ps[k],ps[k+1];area=abs((b[0]-a[0])*(c[2]-a[2])-(b[2]-a[2])*(c[0]-a[0]))/2
   if area<1e-10:continue
   # In these regions, imported top triangles are exactly .25; bottom <0 excluded.
   assert max(abs(v[1]-.25) for v in [a,b,c])<1e-6
   volume+=area*(a[1]+b[1]+c[1])/3;surface_area+=area;count+=1
 measure.append({'region':label,'rectangle_xz':[x0,x1,z0,z1],'actual_imported_triangle_clipped_area':surface_area,'positive_overlap_volume_with_B_ground':volume,'clipped_pieces':count})
assert abs(sum(v['positive_overlap_volume_with_B_ground'] for v in measure)-11.5)<1e-5
old_layout=json.loads((R/'source/environment-layout.json').read_text());new_layout=json.loads((T/'source/environment-layout.json').read_text());support=json.loads((Q/'environment-export-support.json').read_text());mesh=json.loads((Q/'environment-mesh.json').read_text())
assert sha(old)==sha(T/'a-regression/dist/assets/environment.glb')
report={'experiment':'Frozen 013 B replaces 013 A, same environment/route generator, one limited tested migration','default_A_regression':{'original_glb_sha256':sha(old),'parameterized_default_glb_sha256':sha(T/'a-regression/dist/assets/environment.glb'),'byte_identical':True,'original_final_A_outputs_modified':False},'input_B_sha256':sha(T/'dist/assets/courtyard-B.glb'),'old_slot':old_layout['models'][1]['ground_bounds'],'new_slot':new_layout['models'][1]['ground_bounds'],'unmodified_A_environment_failure':{'actual_old_environment_sha256':sha(old),'direct_swap_pass':False,'overlap_regions':measure,'total_positive_volume':sum(x['positive_overlap_volume_with_B_ground'] for x in measure),'reason':'B ground exceeds A socket; explicit positive-volume overlap, not a reusable success'},'revised_B':{'config':'source/config.json','generator':'../source/build-environment.py --output-root reuse-test --config reuse-test/source/config.json','environment_sha256':mesh['environment_glb_sha256'],'triangles':mesh['triangles'],'nonmanifold_edges':mesh['nonmanifold_edges'],'degenerate_faces':mesh['degenerate_faces'],'actual_export_triangle_multiset_equal':support['actual_export_import_oriented_triangle_multiset_equal'],'support_above_zero_triangles':[v['above_zero_triangles'] for v in support['support_domain_checks']],'entry_axis_world_x':8.9,'route_endpoint_xz':[8.9,3.0],'original_path_front_z':2.799999237060547,'original_apron_gap':.20000076293945312,'low_camera_position':[8.9,1.45,5.8],'low_camera_target':[8.9,1.1,-3],'bounds':new_layout['models'][1]['bounds']},'limits':['Only original A and actual B discrete geometry tested; not arbitrary assets or continuous parameter domain','No runtime model switch added','Original B 0.2 apron/path gap remains; no character navigation certification','No GPU or mobile-device claim']}
(Q/'reuse-failure-and-revision.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
# Frame the actual imported B envelope, not reused A dimensions.
import math,itertools
bb=new_layout['models'][1]['bounds'];pos=[21,17,15];target=[10,1,-5];delta=[pos[i]-target[i] for i in range(3)];length=math.sqrt(sum(v*v for v in delta));back=[v/length for v in delta];rl=math.hypot(back[0],back[2]);right=[back[2]/rl,0,-back[0]/rl];up=[back[1]*right[2],back[2]*right[0]-back[0]*right[2],-back[1]*right[0]];tan=math.tan(math.radians(42)/2);projected=[]
for point in itertools.product(*bb):
 d=[point[i]-pos[i] for i in range(3)];dot=lambda a:sum(d[i]*a[i] for i in range(3));depth=-dot(back);projected.append([dot(right)/(depth*tan*1.5),dot(up)/(depth*tan),depth])
assert max(abs(p[i]) for p in projected for i in [0,1])<1 and min(p[2] for p in projected)>.1
(Q/'b-high-camera-projection.json').write_text(json.dumps({'actual_imported_B_bounds':bb,'camera_position':pos,'camera_target':target,'fov_vertical':42,'aspect':1.5,'near':.1,'projected_box_corners_ndc_xy_and_depth':projected,'all_corners_inside':True,'scope':'B actual imported mesh envelope finite projection test; not GPU or subjective framing proof'},indent=2))
