"""Independent decompressed ZIP/native/PNG audit; never inspect only compressed ZIP bytes."""
from pathlib import Path
import zipfile,io,json,hashlib,re,zlib
R=Path(__file__).resolve().parents[1];counts={'entries':0,'png':0,'blend':0,'nested_zips':0}
def inspect(data,label,depth=0):
 assert depth<4
 assert not re.search(rb'/workspace/scratch/[a-z0-9]',data),label
 assert not re.search(rb'libfile_[a-f0-9]{16,}',data),label
 if label.endswith('.blend'):
  counts['blend']+=1;assert all(t not in data for t in [b'/workspace/',b'/home/agent',b'/tmp/']),label
 if label.endswith('.png'):
  counts['png']+=1;assert data[:8]==b'\x89PNG\r\n\x1a\n';pos=8
  while pos<len(data):
   n=int.from_bytes(data[pos:pos+4],'big');typ=data[pos+4:pos+8];payload=data[pos+8:pos+8+n];crc=int.from_bytes(data[pos+8+n:pos+12+n],'big');assert zlib.crc32(typ+payload)&0xffffffff==crc
   assert typ not in [b'tEXt',b'zTXt',b'iTXt'],(label,typ)
   pos+=n+12
  assert pos==len(data)
 if label.endswith('.zip'):
  counts['nested_zips']+=1
  with zipfile.ZipFile(io.BytesIO(data)) as z:
   assert z.testzip() is None
   for n in z.namelist():
    assert not n.startswith('/') and '..' not in Path(n).parts,n
    counts['entries']+=1;inspect(z.read(n),label+'!'+n,depth+1)
files=[R/'dist/source.zip',R.parent/'sd02-spatial-field-complete-v1.zip']
for p in files:inspect(p.read_bytes(),p.name)
out={'passed':True,'scope':'Recursively decompressed ZIP entries, CRC-checked PNG chunks rejecting text/compressed-text metadata, exact native private-path patterns. No GPU claims.','counts':counts,'archives':[{'name':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in files]};(R/'qa/archive-audit.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
