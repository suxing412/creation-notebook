"""SD02 original continuous observation landscape. Blender 4.3 CPU; no renderer required.
Frozen GLBs are read for exact support bounds and never rewritten.
All coordinates in layout JSON are Three Y-up artistic units, not surveyed metres.
"""
import bpy,bmesh,json,math,hashlib,sys,argparse
from pathlib import Path
from mathutils import Vector
parser=argparse.ArgumentParser();parser.add_argument('--output-root');parser.add_argument('--config');args=parser.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
R=Path(args.output_root).resolve() if args.output_root else Path(__file__).resolve().parents[1];A=R/'dist/assets';Q=R/'qa'
for p in [A,Q,R/'source']:p.mkdir(parents=True,exist_ok=True)
config=json.loads(Path(args.config).read_text()) if args.config else {}
models=config.get('models',[('granary-A',[-13,0,-5],'C_site'),('courtyard-A',[10,0,-6],'C_ground')])
assert len(models)==2 and all(len(m)==3 and len(m[1])==3 and all(isinstance(x,(int,float)) and math.isfinite(x) for x in m[1]) for m in models),'Unsupported model configuration'
records=[]
for file,offset,ground_name in models:
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
 bpy.ops.import_scene.gltf(filepath=str(A/(file+'.glb')))
 meshes=[o for o in bpy.context.scene.objects if o.type=='MESH'];points=[]; ground=None
 for o in meshes:
  ps=[o.matrix_world@v.co for v in o.data.vertices]; three=[[p.x+offset[0],p.z+offset[1],-p.y+offset[2]] for p in ps];points+=three
  if o.name==ground_name:ground=[[min(p[i] for p in three),max(p[i] for p in three)] for i in range(3)]
 assert ground is not None
 records.append({'id':file,'file':file+'.glb','position':offset,'scale':1,'rotation_y':0,'sha256':hashlib.sha256((A/(file+'.glb')).read_bytes()).hexdigest(),'bounds':[[min(p[i] for p in points),max(p[i] for p in points)] for i in range(3)],'ground_bounds':ground})
paths={
 'entry':[[0,22],[0,15],[0,11]],
 'granary':[[0,11],[-7,8],[-10.83,5],[-10.83,1.4000000953674316]],
 'courtyard':[[0,11],[8,9],[10,6],[10,3.1999998092651367]],
 'outer_loop':[[8,9],[20,7],[22,0],[22,-14],[13,-18],[-5,-18],[-21,-14],[-21,0],[-17,6],[-7,8]]}
paths=config.get('paths',paths)
assert set(paths)=={'entry','granary','courtyard','outer_loop'} and all(len(ps)>=2 and all(len(p)==2 and all(isinstance(v,(int,float)) and math.isfinite(v) for v in p) for p in ps) and all(a!=b for a,b in zip(ps,ps[1:])) for ps in paths.values()),'Invalid route configuration'
layout={'version':'SD02-environment-v02','coordinate_system':'Three Y-up','units':'original artistic units, not historical dimensions','models':records,'world_bounds':{'min':[-25,-1,-23],'max':[25,6.590000152587891,24]},'paths_xz':paths,'terrain_top_baseline':.25,'terrain_max_y':2.65,'support':'Two recessed sockets at exact original ground slabs: bottom contact y=0 and perimeter side contact y=0..0.25. No extra display plinths.','limits':['not archaeological reconstruction','observation routes, not character navigation or engineering accessibility','CPU mesh checks only; no GPU or continuous collision certification']}
(R/'source/environment-layout.json').write_text(json.dumps(layout,ensure_ascii=False,indent=2))
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
# Grid includes exact source-ground edges. Its material bands are part of top faces,
# not overlapping decals; rectangular cutouts are recessed to provide bottom support.
rects=[(r['ground_bounds'][0][0],r['ground_bounds'][0][1],r['ground_bounds'][2][0],r['ground_bounds'][2][1]) for r in records]
xs=sorted(set([float(i) for i in range(-25,26)]+[v for r in rects for v in r[:2]]));zs=sorted(set([float(i) for i in range(-23,25)]+[v for r in rects for v in r[2:]]))
def segment_distance(x,z,a,b):
 dx=b[0]-a[0];dz=b[1]-a[1];t=max(0,min(1,((x-a[0])*dx+(z-a[1])*dz)/(dx*dx+dz*dz)));return math.hypot(x-a[0]-t*dx,z-a[1]-t*dz)
def route_distance(x,z,ids=None):return min(segment_distance(x,z,a,b) for n,ps in paths.items() if ids is None or n in ids for a,b in zip(ps,ps[1:]))
def inside(x,z):return next((i for i,(a,b,c,d) in enumerate(rects) if a<x<b and c<z<d),None)
outline=[(-24,-13),(-18,-23),(14,-23),(25,-12),(23,14),(8,24),(-6,24),(-25,10)]
layout['outline_xz']=outline;layout['route_half_widths']={'primary':.78,'outer':.58};layout['clearings']={'fork':{'center_xz':[0,11],'radii':[2.25,1.45]},'north_overlook':{'center_xz':[-5,-18],'radii':[2.8,1.8]}};layout['central_landform']={'center_xz':[-3,-7],'radii':[4.5,8],'height_above_baseline':2.1,'purpose':'separates arrival branches without additional architecture'}
(R/'source/environment-layout.json').write_text(json.dumps(layout,ensure_ascii=False,indent=2))
def height(x,z):
 # Peripheral landforms leave all source-ground interfaces and viewing paths flat.
 edge=max(0,min(1,(abs(x)-18)/7),min(1,(-z-17)/6))
 rd=route_distance(x,z); taper=max(0,min(1,(rd-1.8)/3))
 ridge=max(0,1-((x+3)/4.5)**2-((z+7)/8)**2)**2*2.1
 return .25+max(ridge,2.4*edge*taper*(.55+.45*math.cos(z*.19+x*.14)))
# Convex road polygons partition each terrain cell. This is exact line clipping,
# not a higher-resolution staircase or an overlapping road decal.
def halfclip(poly,a,b,sign=1):
 out=[]
 def side(p):return sign*((b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0]))
 for p,q in zip(poly,poly[1:]+poly[:1]):
  dp,dq=side(p),side(q);ip=dp>=-1e-10;iq=dq>=-1e-10
  if ip:out.append(p)
  if ip!=iq:
   t=dp/(dp-dq);out.append((p[0]+t*(q[0]-p[0]),p[1]+t*(q[1]-p[1])))
 return out
def area(p):return abs(sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(p,p[1:]+p[:1])))/2 if len(p)>2 else 0
def partition(poly,cutter):
 remaining=poly;outside=[]
 for a,b in zip(cutter,cutter[1:]+cutter[:1]):
  cut=halfclip(remaining,a,b,-1)
  if area(cut)>1e-10:outside.append(cut)
  remaining=halfclip(remaining,a,b,1)
  if area(remaining)<1e-10:return outside,[]
 return outside,remaining
cutters=[]
def add_cutter(poly,mat):cutters.append((poly,mat,(min(p[0] for p in poly),max(p[0] for p in poly),min(p[1] for p in poly),max(p[1] for p in poly))))
def ellipse(x,z,rx,rz,mat):add_cutter([(x+rx*math.cos(i*math.tau/20),z+rz*math.sin(i*math.tau/20)) for i in range(20)],mat)
for name,ps in paths.items():
 width=.58 if name=='outer_loop' else .78;mat=2 if name=='outer_loop' else 1
 for a,b in zip(ps,ps[1:]):
  dx,dz=b[0]-a[0],b[1]-a[1];l=math.hypot(dx,dz);nx,nz=-dz/l*width,dx/l*width
  add_cutter([(a[0]-nx,a[1]-nz),(b[0]-nx,b[1]-nz),(b[0]+nx,b[1]+nz),(a[0]+nx,a[1]+nz)],mat)
 for x,z in ps[1:-1]:ellipse(x,z,width,width,mat)
# Low-contrast outer route is underneath primary arrival bands at overlaps.
cutters.sort(key=lambda c:0 if c[1]==2 else 1)
ellipse(0,11,2.25,1.45,1);ellipse(-5,-18,2.8,1.8,4)
add_cutter([(-2.1,24),(-1,18),(1,18),(2.1,24)],1)
V=[];F=[];M=[];lookup={};cells={}
def vi(p):
 key=tuple(round(x,7) for x in p)
 if key not in lookup:lookup[key]=len(V);V.append(tuple(key))
 return lookup[key]
def face(ps,mat):
 ids=[vi((x,-z,y)) for x,y,z in ps];ids=[v for k,v in enumerate(ids) if v!=ids[k-1]]
 if len(set(ids))>=3 and len(set(ids))==len(ids):F.append(ids);M.append(mat)
for i in range(len(xs)-1):
 for j in range(len(zs)-1):
  x0,x1=xs[i:i+2];z0,z1=zs[j:j+2];socket=inside((x0+x1)/2,(z0+z1)/2);pts=[(x0,z0),(x1,z0),(x1,z1),(x0,z1)]
  original=pts
  for aa,bb in zip(outline,outline[1:]+outline[:1]):pts=halfclip(pts,aa,bb)
  if area(pts)<1e-9:continue
  hs=[0 if socket is not None else height(x,z) for x,z in original];cells[i,j]=(original,hs,socket)
  parts=[(pts,3 if socket is not None else 0)]
  if socket is None:
   for cutter,mat,(a,b,c,d) in cutters:
    if b<x0 or a>x1 or d<z0 or c>z1:continue
    new=[]
    for poly,oldmat in parts:
     outer,inner=partition(poly,cutter);new.extend((p,oldmat) for p in outer)
     if inner:new.append((inner,mat))
    parts=new
  for poly,mat in parts:face([(x,0 if socket is not None else height(x,z),z) for x,z in poly],mat)
  face([(x,-1,z) for x,z in reversed(pts)],3)
  for aa,bb in zip(pts,pts[1:]+pts[:1]):
   onboundary=any(abs((d[0]-c[0])*(aa[1]-c[1])-(d[1]-c[1])*(aa[0]-c[0]))<1e-7 and abs((d[0]-c[0])*(bb[1]-c[1])-(d[1]-c[1])*(bb[0]-c[0]))<1e-7 for c,d in zip(outline,outline[1:]+outline[:1]))
   if onboundary:face([(aa[0],height(*aa),aa[1]),(aa[0],-1,aa[1]),(bb[0],-1,bb[1]),(bb[0],height(*bb),bb[1])],3)
for (i,j),(pts,hs,socket) in cells.items():
 for k,(di,dj) in enumerate([(0,-1),(1,0),(0,1),(-1,0)]):
  neighbor=cells.get((i+di,j+dj));a=pts[k];b=pts[(k+1)%4];ha=hs[k];hb=hs[(k+1)%4]
  if neighbor is not None and socket is None and neighbor[2] is not None:face([(a[0],ha,a[1]),(a[0],0,a[1]),(b[0],0,b[1]),(b[0],hb,b[1])],3)
# Split all collinear T-junctions introduced by adjacent clipping partitions.
# Spatial buckets keep this deterministic finite operation local.
buckets={}
for idx,p in enumerate(V):buckets.setdefault(tuple(math.floor(v) for v in p),[]).append(idx)
newfaces=[]
for ids in F:
 out=[]
 for ai,bi in zip(ids,ids[1:]+ids[:1]):
  a=V[ai];b=V[bi];delta=[b[k]-a[k] for k in range(3)];length2=sum(q*q for q in delta);candidates=set()
  for x in range(math.floor(min(a[0],b[0]))-1,math.floor(max(a[0],b[0]))+2):
   for y in range(math.floor(min(a[1],b[1]))-1,math.floor(max(a[1],b[1]))+2):
    for z in range(math.floor(min(a[2],b[2]))-1,math.floor(max(a[2],b[2]))+2):candidates.update(buckets.get((x,y,z),[]))
  splits=[(0,ai)]
  for ci in candidates:
   if ci in (ai,bi):continue
   c=V[ci];axes=(0,1) if min(a[2],b[2],c[2])>=.249 else (0,1,2);den=sum(delta[k]**2 for k in axes)
   if den<1e-14:continue
   t=sum((c[k]-a[k])*delta[k] for k in axes)/den
   if 1e-7<t<1-1e-7 and sum((c[k]-a[k]-t*delta[k])**2 for k in axes)<1e-12:splits.append((t,ci))
  out.extend(idx for t,idx in sorted(splits))
 newfaces.append(out)
F=newfaces
mesh=bpy.data.meshes.new('SD02_integrated_landscape');mesh.from_pydata(V,[],F);mesh.update();ob=bpy.data.objects.new('SD02 original landscape with support sockets',mesh);bpy.context.collection.objects.link(ob)
for name,col in [('earth',(.29,.34,.26)),('arrival',(.63,.55,.39)),('outer observation loop',(.35,.39,.29)),('land edge and support',(.23,.26,.20)),('north overlook clearing',(.46,.47,.34))]:
 m=bpy.data.materials.new(name);m.diffuse_color=(*col,1);m.use_nodes=True;m.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(*col,1);m.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.95;ob.data.materials.append(m)
for p,m in zip(mesh.polygons,M):p.material_index=m
bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.recalc_face_normals(bm,faces=bm.faces);bm.to_mesh(mesh);bm.free()
# Dissolve coplanar interior grid edges but retain material boundaries and relief.
bpy.context.view_layer.objects.active=ob;ob.select_set(True)
mod=ob.modifiers.new('Coplanar grid reduction','DECIMATE');mod.decimate_type='DISSOLVE';mod.angle_limit=.001;mod.delimit={'MATERIAL'}
bpy.ops.object.modifier_apply(modifier=mod.name);mesh=ob.data
bm=bmesh.new();bm.from_mesh(mesh);volume=bm.calc_volume(signed=True);bad_edges=sum(not e.is_manifold for e in bm.edges);bad_faces=sum(f.calc_area()<1e-10 for f in bm.faces);bm.free()

if bad_edges:
 bm=bmesh.new();bm.from_mesh(mesh);print('BAD_EDGES',[(list(e.verts[0].co),list(e.verts[1].co),len(e.link_faces)) for e in bm.edges if not e.is_manifold]);bm.free()
assert bad_edges==0,(bad_edges,'non-manifold');assert bad_faces==0;assert volume>0
# Bind finite-generation proof to actual bytes. Terrain surface at source slabs is
# 0, while slab volume is y in (0,.25): no positive-volume overlap by construction.
checks={'version':'SD02-environment-v02','scope':'exact generated grid and rectangular frozen ground supports; not arbitrary mesh containment or continuous camera collision','vertices':len(mesh.vertices),'faces':len(mesh.polygons),'triangles':sum(len(p.vertices)-2 for p in mesh.polygons),'nonmanifold_edges':bad_edges,'degenerate_faces':bad_faces,'signed_volume':volume,'source_sha256':{r['file']:r['sha256'] for r in records},'contacts':[],'path_surface':'convex clipped continuous road-band boundaries as terrain faces; no grid stair-step or overlapping decal mesh','max_terrain_y':max(v.co.z for v in mesh.vertices)}
for r in records:
 bb=r['ground_bounds'];checks['contacts'].append({'source':r['file'],'bottom_plane_y':0,'bottom_rectangle_xz':[bb[0],bb[2]],'side_planes':[{'axis':'x','coordinate':v,'span_z':bb[2],'span_y':[0,.25]} for v in bb[0]]+[{'axis':'z','coordinate':v,'span_x':bb[0],'span_y':[0,.25]} for v in bb[2]],'classification':'zero-volume support/interface; no source ground shape changes','positive_volume_overlap':0})
bpy.context.view_layer.objects.active=ob;ob.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(A/'environment.glb'),export_format='GLB',use_selection=True,export_cameras=False,export_lights=False)
# No paths packed in custom properties or text blocks; final native is geometry-only.
for text in list(bpy.data.texts):bpy.data.texts.remove(text)
bpy.data.batch_remove(ids=[ws for ws in bpy.data.workspaces if ws.name!='Layout'])
bpy.data.batch_remove(ids=[screen for screen in bpy.data.screens if screen.name!='Layout' and screen.users==0])
bpy.context.scene.render.filepath='//preview.png'
bpy.ops.wm.save_as_mainfile(filepath=str(A/'environment.blend'))
assert not any(p in (A/'environment.blend').read_bytes() for p in [b'/home/agent',b'/workspace/',b'/tmp/']), 'Private path in native file'
checks['environment_glb_sha256']=hashlib.sha256((A/'environment.glb').read_bytes()).hexdigest();checks['environment_blend_sha256']=hashlib.sha256((A/'environment.blend').read_bytes()).hexdigest();(Q/'environment-mesh.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks))
# Independent actual export/reimport triangle and support-domain check.
from collections import Counter
def triangles(objects):
 out=[]
 for obj in objects:
  if obj.type!='MESH':continue
  obj.data.calc_loop_triangles()
  for tri in obj.data.loop_triangles:out.append([obj.matrix_world@obj.data.vertices[i].co for i in tri.vertices])
 return out
def keys(ts):
 result=[]
 for t in ts:
  p=[tuple(round(float(v),5) for v in a) for a in t]
  result.append(min(tuple(p[i:]+p[:i]) for i in range(3)))
 return Counter(result)
native=triangles([ob]);bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
bpy.ops.import_scene.gltf(filepath=str(A/'environment.glb'));actual=triangles(bpy.context.scene.objects)
assert keys(native)==keys(actual),'GLB oriented triangles differ'
def clip(poly,axis,bound,keep):
 result=[]
 if not poly:return result
 for a,b in zip(poly,poly[1:]+poly[:1]):
  aa=(a[axis]-bound)*keep>=0;bb=(b[axis]-bound)*keep>=0
  if aa:result.append(a)
  if aa!=bb:
   t=(bound-a[axis])/(b[axis]-a[axis]);result.append([a[k]+t*(b[k]-a[k]) for k in range(3)])
 return result
support=[]
for r in records:
 bb=r['ground_bounds'];positive=[];nonboundary=0
 # Clip against a 1e-5 inset of the original rectangle: legal vertical side
 # contacts excluded explicitly, not an entire object pair blanket exception.
 for ti,t in enumerate(actual):
  ps=[[v.x,v.z,-v.y] for v in t]
  for axis,bound,keep in [(0,bb[0][0]+1e-5,1),(0,bb[0][1]-1e-5,-1),(2,bb[2][0]+1e-5,1),(2,bb[2][1]-1e-5,-1)]:ps=clip(ps,axis,bound,keep)
  if len(ps)<3:continue
  area=abs(sum(a[0]*b[2]-b[0]*a[2] for a,b in zip(ps,ps[1:]+ps[:1])))/2
  if area<1e-10:continue
  nonboundary+=1
  if max(p[1] for p in ps)>1e-6:positive.append(ti)
 assert not positive,(r['id'],positive[:10])
 support.append({'model':r['id'],'clipped_nonzero_area_triangles':nonboundary,'above_zero_triangles':positive,'inset':1e-5,'height_tolerance':1e-6,'remaining_boundary':'vertical interfaces separately recorded in environment-mesh.json'})
(Q/'environment-export-support.json').write_text(json.dumps({'environment_sha256':hashlib.sha256((A/'environment.glb').read_bytes()).hexdigest(),'actual_export_import_oriented_triangle_multiset_equal':True,'native_triangles':len(native),'actual_triangles':len(actual),'source_world_min_y':[r['bounds'][1][0] for r in records],'source_footprints_contained_in_ground_slabs':[r['bounds'][0]==r['ground_bounds'][0] and r['bounds'][2]==r['ground_bounds'][2] for r in records],'support_domain_checks':support,'scope':'finite assets, inset-domain top/bottom checks plus recorded boundary contacts. Does not re-certify internal source-model intersections or arbitrary continuously parameterized geometry.'},indent=2))
