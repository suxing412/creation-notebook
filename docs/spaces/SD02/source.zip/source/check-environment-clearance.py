"""Finite low-camera yaw/aspect sweep with full-near-rectangle distance bound."""
import bpy,json,math,hashlib
from pathlib import Path
from mathutils import Vector,Matrix
from mathutils.bvhtree import BVHTree
R=Path(__file__).resolve().parents[1];A=R/'dist/assets';Q=R/'qa'
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
for file,off in [('environment.glb',(0,0,0)),('granary-A.glb',(-13,5,0)),('courtyard-A.glb',(10,6,0))]:
 before=set(bpy.context.scene.objects);bpy.ops.import_scene.gltf(filepath=str(A/file))
 for o in set(bpy.context.scene.objects)-before:
  if o.parent is None:o.location+=Vector(off)
bpy.context.view_layer.update();vs=[];fs=[]
for o in bpy.context.scene.objects:
 if o.type!='MESH':continue
 n=len(vs);vs.extend(o.matrix_world@v.co for v in o.data.vertices);fs.extend([n+i for i in p.vertices] for p in o.data.polygons)
bvh=BVHTree.FromPolygons(vs,fs)
def conv(p):return Vector((p[0],-p[2],p[1]))
def nearest(p):return bvh.find_nearest(p)[3]
contract=json.loads((Q/'runtime-camera-presets.json').read_text());entry=next(v for v in contract['views'] if v['id']=='entry' and not v['raised']);assert entry['position']==[1.5,3.4,29]
views=[('entry',entry['position'],entry['target']),('granary',[-8.2,2.4,5.2],[-12.2,1.65,-2]),('courtyard',[10,1.45,5.8],[10,1.1,-2])]
descent_reports=[]
for name,pos,target in views:
 ds=[nearest(conv([pos[0],12+(pos[1]-12)*i/106,pos[2]])) for i in range(107)]
 descent_reports.append({'place':name,'samples':107,'min_nearest_geometry':min(ds),'camera_clearance_radius':.15,'passed':min(ds)>.15,'scope':'fixed XZ vertical descent samples; not continuous proof'})
rows=[];tan=math.tan(math.radians(42)/2);near=.1
for name,p,t in views:
 pos=Vector(p);d=Vector(t)-pos
 for yaw in [-.14,-.07,0,.07,.14]:
  direction=Matrix.Rotation(yaw,3,'Y')@d;rotation=conv(direction).to_track_quat('-Z','Y').to_matrix()
  for w,h in [(260,480),(390,844),(1200,800),(2000,480)]:
   asp=w/h;corners=[conv(p)+rotation@Vector((sx*near*tan*asp,sy*near*tan,-near)) for sx in [-1,1] for sy in [-1,1]]
   distances=[nearest(c) for c in corners];radius=near*math.sqrt(1+tan*tan*(1+asp*asp));center_distance=nearest(conv(p));lower_bound=center_distance-radius
   assert min(distances)>.15 and lower_bound>.15
   rows.append({'place':name,'yaw_radians':yaw,'viewport':[w,h],'near_corner_min_distance':min(distances),'near_corner_distances':distances,'camera_distance':center_distance,'camera_to_near_farthest_corner':radius,'entire_near_rectangle_clearance_lower_bound':lower_bound,'scope':'Distance-to-mesh is 1-Lipschitz: subtract maximum camera-to-rectangle distance. Covers every near-rectangle point at this camera, independently of yaw; not movement collision.'})
out={'environment_sha256':hashlib.sha256((A/'environment.glb').read_bytes()).hexdigest(),'source_sha256':{f:hashlib.sha256((A/f).read_bytes()).hexdigest() for f in ['granary-A.glb','courtyard-A.glb']},'runtime_camera_contract_sha256':hashlib.sha256((Q/'runtime-camera-presets.json').read_bytes()).hexdigest(),'entry_portrait_target':[-10,2.6,-1],'entry_portrait_scope':'Same fixed position and FOV; entire near rectangle bound independent of target, including portrait target.','fov_vertical':42,'near':near,'camera_clearance_radius':.15,'cases':rows,'descent_checks':descent_reports,'all_pass':True,'world_max_y':max(p.z for p in vs),'high_camera_y':12,'high_camera_point_clearance_from_max_y':12-max(p.z for p in vs),'limits':['fixed exterior low positions only; no forward movement','finite 5 yaw × 4 viewport sweep per position; all-near-rectangle bound applies to fixed positions','not GPU or dynamic collision testing']};assert out['world_max_y']<6.6
(Q/'environment-yaw-clearance.json').write_text(json.dumps(out,indent=2));print('cases',len(rows),'minimum near rectangle lower bound',min(r['entire_near_rectangle_clearance_lower_bound'] for r in rows),'world max Y',out['world_max_y'])
