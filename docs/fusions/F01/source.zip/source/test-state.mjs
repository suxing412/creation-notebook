import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';import {ids,routeFromHash,interpolate} from '../dist/state.mjs';
const routes=JSON.parse(readFileSync(new URL('../dist/assets/routes.json',import.meta.url)));
for(const id of ids)assert.equal(routeFromHash('#'+id),id);
for(const hash of ['','#reading','#missing','#%68all'])assert.equal(routeFromHash(hash),null);
assert.deepEqual(interpolate([1,2,3],[4,5,6],-1),[1,2,3]);assert.deepEqual(interpolate([1,2,3],[4,5,6],2),[4,5,6]);
let count=0;for(const a of ids)for(const b of ids)if(a!==b)for(let i=0;i<=100;i++){const p=interpolate(routes[a].position,routes[b].position,i/100);assert(p[1]>=4.5&&p[2]>=6.8);count++;}
console.log(`PASS parser 7 cases, interpolation clamping, ${count} route samples; not a GPU test`);
