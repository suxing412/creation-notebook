# F01 · 轨与翼 · 空间索引

原创 3D 展厅和空间网页设计，搭配原创 001 AETHER / 002 NACRE 模型。第三方依赖仅为本地 Three.js；MIT license 见 dist/vendor/THREE-LICENSE。两件输入 GLB 原件保持不变。

运行网页：在项目目录执行 `python -m http.server 8000`，访问 `/dist/`。无 GPU/JavaScript 仍可阅读，WebGL 可用才加载空间交互。

重建：安装 Blender 4.3+，执行 `blender -b --python source/build.py`。生成三章 PNG、GLB、BLEND。运行 `python source/check.py`（需要 numpy），以及 `node source/test-state.mjs`。`package.py` 需要 Pillow，清除 PNG 文本元数据、生成联系表／HTML 报告／可下载源码包。

最终 blend 另从网页下载，源码 zip 不重复包含。当前版没有制造／结构安全认证；完整限制见 dist/reports/qa.html。
