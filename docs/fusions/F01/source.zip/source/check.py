import json,struct,pathlib,itertools,numpy as np
root=pathlib.Path(__file__).resolve().parent.parent;data=(root/'dist/assets/spatial-index.glb').read_bytes();jsn=struct.unpack_from('<I',data,12)[0];g=json.loads(data[20:20+jsn]);off=20+jsn;blob=data[off+8:];ct={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'};nc={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
def accessor(i):
 a=g['accessors'][i];v=g['bufferViews'][a['bufferView']];dt=np.dtype(ct[a['componentType']]);n=nc[a['type']];return np.ndarray((a['count'],n),dtype=dt,buffer=blob,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',dt.itemsize*n),dt.itemsize)).copy()
triangles=degenerate=duplicate=0
for mesh in g['meshes']:
 seen=set()
 for p in mesh['primitives']:
  v=accessor(p['attributes']['POSITION']);idx=accessor(p['indices']).reshape(-1,3)
  for face in idx:
   t=v[face];triangles+=1;degenerate+=bool(np.linalg.norm(np.cross(t[1]-t[0],t[2]-t[0]))<1e-10)
   key=tuple(sorted(tuple(round(float(x),7) for x in q) for q in t));duplicate+=key in seen;seen.add(key)
routes=json.loads((root/'dist/assets/routes.json').read_text());travel=[]
for a,b in itertools.permutations(routes,2):
 samples=np.array([np.array(routes[a]['position'])*(1-t)+np.array(routes[b]['position'])*t for t in np.linspace(0,1,101)])
 # nearest exhibition front bound z=0; cameras remain entirely on front side, minimum distance reported.
 travel.append({'from':a,'to':b,'samples':len(samples),'minimumCameraZ':float(samples[:,2].min()),'minimumCameraHeight':float(samples[:,1].min())})
result={'meshes':len(g['meshes']),'triangles':triangles,'zeroAreaAtDoubleAreaTolerance1e-10':degenerate,'duplicateCoordinateTrianglesWithinMeshRounded7Decimals':duplicate,'cameraRoutes':travel,'geometryScope':'Triangle degeneracy and same-mesh exact coordinate duplicates only; not full BVH/self-intersection/coplanar-overlap certification. Original artifact assembly contacts remain inherited. New closed boxes deliberately contact foundation; portal lintels overlap uprights as structural joints. Camera position paths stay at z>=7.8 while exhibit front is z<=0; GPU view/frustum occlusion not tested.','plinthTopY':.8,'artifactBottomY':1.05,'deliberateSuspensionGap':.25}
(root/'dist/reports/geometry.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False))
assert degenerate==0 and duplicate==0
# Conservative AABB cross-check: no zero count is treated as proof of general self-intersection freedom.
def matrix(n):
 if 'matrix' in n:return np.array(n['matrix']).reshape(4,4).T
 t=np.array(n.get('translation',[0,0,0]));s=np.array(n.get('scale',[1,1,1]));x,y,z,w=n.get('rotation',[0,0,0,1]);r=np.array([[1-2*y*y-2*z*z,2*x*y-2*z*w,2*x*z+2*y*w],[2*x*y+2*z*w,1-2*x*x-2*z*z,2*y*z-2*x*w],[2*x*z-2*y*w,2*y*z+2*x*w,1-2*x*x-2*y*y]]);m=np.eye(4);m[:3,:3]=r@np.diag(s);m[:3,3]=t;return m
bounds=[]
def visit(i,parent):
 n=g['nodes'][i];world=parent@matrix(n)
 if 'mesh' in n:
  points=np.concatenate([accessor(p['attributes']['POSITION']) for p in g['meshes'][n['mesh']]['primitives']]);points=np.c_[points,np.ones(len(points))]@world.T;bounds.append((n.get('name',''),points[:,:3].min(axis=0),points[:,:3].max(axis=0)))
 for c in n.get('children',[]):visit(c,world)
for i in g['scenes'][g.get('scene',0)]['nodes']:visit(i,np.eye(4))
isartifact=lambda name:name.startswith('Orbit / ') or name.startswith('Tide / ')
cross=[];newpairs=[]
for (a,lo,hi),(b,lo2,hi2) in itertools.combinations(bounds,2):
 overlap=np.minimum(hi,hi2)-np.maximum(lo,lo2)
 if np.all(overlap>1e-6):
  if isartifact(a)!=isartifact(b):cross.append([a,b,overlap.tolist()])
  if not isartifact(a) and not isartifact(b):newpairs.append([a,b,overlap.tolist()])
result['artifactEnvironmentPositiveAABBOverlaps']=cross;result['newEnvironmentPositiveAABBOverlaps']=newpairs;result['aabbScope']='Broad-phase only. Original-artifact internal pairs excluded. Positive overlaps in portal joints are classified intentional; touching floor surfaces excluded by 1e-6 tolerance.'
(root/'dist/reports/geometry.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print('artifact/environment AABB candidates:',len(cross),'new environment candidates:',len(newpairs))
