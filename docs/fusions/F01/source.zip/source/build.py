import bpy, bmesh, math, json, os
from mathutils import Vector
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT=os.path.join(ROOT,'dist','assets')
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
def mat(n,c,metal=0):
 m=bpy.data.materials.new(n); m.diffuse_color=(*c,1); m.use_nodes=True; p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=(*c,1); p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=.36 if metal else .68;return m
stone=mat('Chalk limestone',(.55,.49,.38)); dark=mat('Midnight slate',(.043,.065,.073)); gold=mat('Brushed champagne',(.58,.38,.14),.65); warm=mat('Sand plaster',(.70,.56,.37)); glass=mat('Archive jade',(.07,.27,.23),.35)
def xyz(p):return (p[0],-p[2],p[1])
def box(n,p,s,m):
 bpy.ops.mesh.primitive_cube_add(size=1,location=xyz(p));o=bpy.context.object;o.name=n;o.dimensions=(s[0],s[2],s[1]);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m);return o
# Three world Y is up. A low open pavilion with a clear central concourse.
box('Foundation',(0,-.3,0),(25,.6,13),dark)
box('Concourse',(0,.04,2),(23,.08,4),stone)
for x,n,m in [(-7,'Orbit',dark),(7,'Tide',warm)]:
 box(n+' plinth',(x,.4,-2),(4.5,.8,4),m)
 box(n+' rear wall',(x,3,-4.8),(5.6,6,.32),m)
 for dx in [-2.65,2.65]:box(n+' brass edge',(x+dx,3,-4.58),(.07,6,.06),gold)
# Separate ribs, not intersecting duplicate planes; intentional bottom slab contact.
for x in [-11.5,-10,-8.5,-5.5,-4,-2.5,2.5,4,5.5,8.5,10,11.5]:
 box('Colonnade',(x,2.5,-5.6),(.16,5,.24),gold)
# two stepped reading islands and deliberately freestanding portals
for x in [-7,7]:
 box('Portal lintel',(x,6,-1),(6,.18,.22),gold)
 for dx in [-3,3]:box('Portal upright',(x+dx,3,-1),(.18,6,.22),gold)
# Compass-like inset route, raised with physical clearance, no coincident overlays
for x in [-7,0,7]:box('Wayfinding threshold',(x,.10,3),(2.2,.04,.1),gold)
box('Index monolith',(0,1,-3.8),(1.1,2,.5),glass)
base=os.path.dirname(ROOT)
for file,x,size in [('aether-reliquary.glb',-7,3.5),('nacre-glider.glb',7,4.0)]:
 path=os.path.join(ROOT,'source','models',file)
 bpy.ops.object.select_all(action='DESELECT');bpy.ops.import_scene.gltf(filepath=path)
 obs=[o for o in bpy.context.selected_objects if o.type=='MESH']; pts=[o.matrix_world@Vector(v) for o in obs for v in o.bound_box];lo=Vector(tuple(min(v[i] for v in pts) for i in range(3)));hi=Vector(tuple(max(v[i] for v in pts) for i in range(3))); center=(lo+hi)/2;scale=size/max(hi-lo)
 # apply imported world transforms to meshes then shared normalization
 for o in obs:
  world=o.matrix_world.copy();o.parent=None;o.matrix_world=world
  for v in o.data.vertices:v.co=world@v.co
  o.matrix_world.identity()
  for v in o.data.vertices:v.co=(v.co-center)*scale+Vector((x,2, .8+(hi.z-lo.z)*scale/2+.25))
  o.name=('Orbit / ' if x<0 else 'Tide / ')+o.name
# Built-in text geometry anchors the spatial chapter identity in the scene itself.
for x,label in [(-7,'01 / ORBIT'),(7,'02 / TIDE')]:
 bpy.ops.object.text_add(location=(x-2.0,4.59,5.0),rotation=(math.pi/2,0,0));o=bpy.context.object;o.name='Chapter sign '+label;o.data.body=label;o.data.size=.38;o.data.extrude=.003;o.data.materials.append(gold);bpy.ops.object.convert(target='MESH')
for o in bpy.data.objects:
 if o.type=='MESH' and o.name.startswith('Chapter sign'):
  bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.triangulate(bm,faces=list(bm.faces));bmesh.ops.delete(bm,geom=[f for f in bm.faces if f.calc_area()<1e-8],context='FACES');bm.to_mesh(o.data);bm.free()
routes={'hall':{'title':'序厅','position':[0,10.5,24],'target':[0,1.6,-1]},'orbit':{'title':'星轨档案','position':[-3,4.5,7.8],'target':[-7,2.5,-2]},'tide':{'title':'潮翼档案','position':[3.5,4.8,9.5],'target':[7,2.6,-2]}}
with open(os.path.join(OUT,'routes.json'),'w') as f:json.dump(routes,f,ensure_ascii=False,indent=2)
# Export geometry before lighting/cameras; same asset in both renderers.
bpy.ops.object.select_all(action='SELECT');bpy.ops.export_scene.gltf(filepath=os.path.join(OUT,'spatial-index.glb'),export_format='GLB',use_selection=True)
world=bpy.context.scene.world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.22,.25,.28,1);world.node_tree.nodes['Background'].inputs[1].default_value=.45
for n,p,power,size in [('Key',(-3,11,5),2500,9),('Tide',(9,8,1),1600,7),('Rim',(-8,8,-6),1800,6)]:
 bpy.ops.object.light_add(type='AREA',location=xyz(p));o=bpy.context.object;o.name=n;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.rotation_euler=(Vector(xyz((p[0],0,-2)))-o.location).to_track_quat('-Z','Y').to_euler()
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=128;scene.cycles.use_denoising=False;scene.render.resolution_x=1440;scene.render.resolution_y=960;scene.render.resolution_percentage=100;scene.view_settings.view_transform='AgX'
bpy.ops.object.camera_add();cam=bpy.context.object;scene.camera=cam;cam.data.type='PERSP';cam.data.lens=35;cam.data.sensor_width=36
for key,r in routes.items():
 cam.location=xyz(r['position']);cam.rotation_euler=(Vector(xyz(r['target']))-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=os.path.join(OUT,key+'.png');bpy.ops.render.render(write_still=True)
scene.render.filepath='//tide.png'
for screen in bpy.data.screens:
 for area in screen.areas:
  for space in area.spaces:
   if space.type=='FILE_BROWSER' and space.params:space.params.directory=b'//'
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT,'spatial-index.blend'))
