import pathlib,re,html,json,zipfile
from PIL import Image,ImageOps,ImageDraw
R=pathlib.Path(__file__).resolve().parent.parent;D=R/'dist'
for p in (D/'assets').glob('*.png'):
 im=Image.open(p);im.save(p)
# Contact sheet uses only authored offline scene renders.
canvas=Image.new('RGB',(1200,290),'#111a1c');draw=ImageDraw.Draw(canvas)
for i,k in enumerate(['hall','orbit','tide']):
 im=Image.open(D/'assets'/f'{k}.png').convert('RGB');im.thumbnail((390,260));canvas.paste(im,(i*400,0));draw.text((i*400+10,268),k.upper(),fill='#e6dfd0')
canvas.save(D/'assets/contact-sheet.jpg',quality=90)
def inline(s):
 s=html.escape(s);s=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'<a href="\2">\1</a>',s);s=re.sub(r'`([^`]+)`',r'<code>\1</code>',s);return s
for p in (D/'reports').glob('*.md'):
 chunks=[]
 for block in p.read_text().split('\n\n'):
  if block.startswith('# '):chunks.append('<h1 style="font-size:38px">'+inline(block[2:])+'</h1>')
  elif block.startswith('## '):chunks.append('<h2>'+inline(block[3:])+'</h2>')
  else:chunks.append('<p>'+inline(block).replace('\n','<br>')+'</p>')
 if p.stem=='review':chunks.append('<h2>实际渲染前后</h2><p>初版相机过近与修订后的序厅全景；两图相机不同，比较取景，不比较材质。</p><img style="width:100%" src="../assets/hall-before.png" alt="初版两翼边框被裁切"><img style="width:100%" src="../assets/hall.png" alt="修订后两翼门户完整进入画面"><h2>三章真实相机视图</h2><img style="width:100%" src="../assets/contact-sheet.jpg" alt="序厅、星轨、潮翼三视图">')
 p.with_suffix('.html').write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>F01 '+p.stem+'</title><link rel="stylesheet" href="../style.css"><header><a href="../index.html">← 返回轨与翼</a></header><main style="max-width:900px;padding:40px 6vw;overflow-wrap:anywhere">'+''.join(chunks)+'</main></html>')
p=D/'index.html';s=p.read_text();s=re.sub(r'reports/(review|qa|references)\.md',r'reports/\1.html',s);p.write_text(s)
# Archive excludes separately downloadable Blender, previous auto-backup and itself.
with zipfile.ZipFile(D/'source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for folder in [R/'source',D]:
  for p in folder.rglob('*'):
   if p.is_file() and p.name not in ['source.zip','spatial-index.blend'] and not p.suffix=='.blend1':z.write(p,p.relative_to(R))
