import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import path from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const nav=await import(pathToFileURL(root+'/dist/navigation.mjs'));
const THREE=await import(pathToFileURL(root+'/dist/vendor/three.module.js'));
const config=JSON.parse(fs.readFileSync(root+'/dist/assets/scene.json'));
const source=fs.readFileSync(root+'/dist/app.js','utf8');
const defer=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b});return {promise,resolve,reject}};
const tick=()=>new Promise(r=>setImmediate(r));
class Element{
 constructor(id='',data={}){this.id=id;this.dataset=data;this.handlers={};this.attributes={};this.style={};this.textContent='';this.hidden=false;this.disabled=false;this.checked=false;this.clientWidth=648;this.clientHeight=432;this.classList={add(){},remove(){}};this.focusCount=0;}
 addEventListener(k,fn){(this.handlers[k]??=[]).push(fn)}
 emit(k,e={}){return Promise.all((this.handlers[k]||[]).map(fn=>fn(e)))}
 setAttribute(k,v){this.attributes[k]=v} removeAttribute(k){delete this.attributes[k]}
 toggleAttribute(k,v){if(v)this.setAttribute(k,'');else this.removeAttribute(k)}
 getAttribute(k){return this.attributes[k]}
 focus(){this.focusCount++} append(e){(this.children??=[]).push(e);e.parent=this;} remove(){if(this.parent)this.parent.children=this.parent.children.filter(e=>e!==this)} getBoundingClientRect(){return {left:0,top:0,width:648,height:432}}
}
async function boot(hash='',live=false){
 const nodes={};for(const id of ['poster','scene-status','enable','stage','canvas','reduce-motion','scene-number','scene-label','motion-control','scene-instruction','reading','overview','light','fold'])nodes[id]=new Element(id);
 nodes.poster.src='assets/overview.png';nodes['scene-label'].textContent='案上全景';
 const links=config.routes.map(r=>{const a=new Element('',{route:r.id});a.attributes.href='#'+r.id;return a});
 const spots=config.routes.map(r=>{const a=new Element('',{hotspot:r.id});a.attributes.href='#'+r.id;return a});
 const credit=new Element(),window=new Element(),images=[],parses=[],renderers=[],assets=[];
 class FakeRenderer{constructor(){this.domElement=new Element();this.shadowMap={};this.id=renderers.length+1;this.disposed=0;renderers.push(this)}setPixelRatio(){}setClearColor(){}setSize(){}render(scene,camera){scene.updateMatrixWorld(true);camera.updateMatrixWorld(true)}dispose(){this.disposed++}}
 class FakeLoader{parseAsync(bytes){const d=defer();parses.push({file:new TextDecoder().decode(bytes),...d});return d.promise}}
 function makeAsset(){const group=new THREE.Group(),geometry=new THREE.BoxGeometry(.1,.1,.1),material=new THREE.MeshStandardMaterial(),stats={geometry:0,material:0};geometry.addEventListener('dispose',()=>stats.geometry++);material.addEventListener('dispose',()=>stats.material++);group.add(new THREE.Mesh(geometry,material));assets.push(stats);return {scene:group,stats};}
 const fetchMock=async(url,options)=>url.includes('scene.json')?{ok:true,json:async()=>structuredClone(config)}:{ok:true,arrayBuffer:async()=>new TextEncoder().encode(url).buffer};

 const history={state:null,replaceState(s){this.state=s}},location={hash};
 const document={querySelector(s){return s==='.image-credit'?credit:nodes[s.slice(1)]},querySelectorAll(s){return s==='[data-route]'?links:spots},getElementById(id){return nodes[id]}};
 const ctx=vm.createContext({...nav,console,document,window,history,location,Image:class{constructor(){this.job=defer();images.push(this)}decode(){return this.job.promise}},fetch:fetchMock,AbortController,DOMException,matchMedia:()=>({matches:false,addEventListener(){}}),ResizeObserver:class{observe(){}disconnect(){}},cancelAnimationFrame(){},requestAnimationFrame(){return 1},performance:{now:()=>0},devicePixelRatio:1,__dynamic:async(spec)=>{if(!live)throw Error('deliberate unavailable module');return spec==='three'?{...THREE,WebGLRenderer:FakeRenderer}:{GLTFLoader:FakeLoader}},});
 const text=source.replace(/^import[^\n]+\n/,'').replace(/\bimport\(/g,'__dynamic(');
 const run=vm.runInContext(`(async()=>{${text};globalThis.__audit={applyHash,fail,getState:()=>({current,routeEpoch:typeof routeEpoch==='undefined'?request:routeEpoch,liveEpoch:typeof liveEpoch==='undefined'?null:liveEpoch,loading,mode,gl:!!gl}),};})()`,ctx);
 await tick();assert.equal(images.length,1);images.shift().job.resolve();await run;
 return {nodes,links,spots,window,images,history,location,ctx,parses,renderers,assets,makeAsset,audit:ctx.__audit,async route(hash,state=null){history.state=state;location.hash=hash;const p=window.emit('hashchange');await tick();return {p,image:images.at(-1)}}};
}
const results=[];
{
 const h=await boot();const light=await h.route('#light'),fold=await h.route('#fold');fold.image.job.resolve();await fold.p;light.image.job.resolve();await light.p;
 assert.equal(h.audit.getState().current,'fold');results.push({test:'out-of-order image decode',passed:true,rendered:'fold'});
}
{
 const h=await boot();const light=await h.route('#light');light.image.job.reject(Error('broken image'));await light.p;
 assert.equal(h.audit.getState().current,'overview');assert.equal(h.nodes.poster.src,'assets/overview.png');assert.equal(h.nodes['scene-label'].textContent,'案上全景');results.push({test:'failed image preserves old route, label and poster',passed:true});
}
{
 const h=await boot();const light=await h.route('#light');const enablePromise=h.nodes.enable.emit('click');await enablePromise;await tick();light.image.job.resolve();await light.p;
 const actual=h.audit.getState();const defect=actual.current!=='light';results.push({test:'renderer initialization failure during pending chapter decode',passed:!defect,actual,hash:h.location.hash,poster:h.nodes.poster.src,status:h.nodes['scene-status'].textContent});
}
{
 const h=await boot();const light=await h.route('#light');light.image.job.resolve();await light.p;const reading=await h.route('#reading');reading.image.job.resolve();await reading.p;assert.equal(h.history.state.deskAtlasScene,'light');const saved=structuredClone(h.history.state);const fold=await h.route('#fold');fold.image.job.resolve();await fold.p;const back=await h.route('#reading',saved);back.image.job.resolve();await back.p;assert.equal(h.audit.getState().current,'light');results.push({test:'reading entry restores recorded last scene on Back-like history event',passed:true,limitation:'Synthetic state/hash event; not native browser history automation.'});
}
if(source.includes('async function startLive()')){
 const h=await boot('',true);await h.nodes.enable.emit('click');await tick();assert.equal(h.parses.length,1);const old=h.parses.shift();assert.equal(h.audit.getState().loading,true);
 await h.nodes.enable.emit('click');assert.equal(h.audit.getState().loading,false);assert.equal(h.audit.getState().mode,'poster');
 await h.nodes.enable.emit('click');await tick();for(let i=0;i<3;i++){assert.equal(h.parses.length,1);h.parses.shift().resolve(h.makeAsset());await tick();}
 assert.equal(h.audit.getState().mode,'live');const active=h.renderers.at(-1);assert.equal(active.disposed,0);assert.equal(h.nodes.canvas.children.length,1);
 const stale=h.makeAsset();old.resolve(stale);await tick();assert.equal(h.audit.getState().mode,'live');assert.equal(active.disposed,0);assert.equal(h.renderers[0].disposed,1);assert.equal(stale.stats.geometry,1);assert.equal(stale.stats.material,1);
 await h.nodes.enable.emit('click');assert.equal(h.audit.getState().mode,'poster');assert.equal(h.nodes.canvas.children.length,0);assert.equal(active.disposed,1);
 results.push({test:'cancel during old GLTF parse, restart, newest commit, then old parse completes',passed:true,staleParsedResourcesDisposed:stale.stats,activeRendererUnaffected:true});
 results.push({test:'explicit offline after live commit',passed:true,canvasCount:h.nodes.canvas.children.length,activeRendererDisposeCalls:active.disposed,limitation:'Real Three CPU scene with stub renderer and synthetic assets. Does not establish GPU teardown.'});
}
assert(results.every(r=>r.passed));
console.log(JSON.stringify({passed:true,appSHA256:createHash('sha256').update(source).digest('hex'),scope:'Node VM executes actual app.js with synthetic DOM, Image and import failure. No browser, WebGL or GPU evidence.',source:'dist/app.js',results},null,2));
