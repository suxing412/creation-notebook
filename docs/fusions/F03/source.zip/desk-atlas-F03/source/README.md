# Desk Atlas / 案上秩序 — F03

Version 0.2.0 · seed 0 · original spatial reading experiment.

This is the third fusion round, pairing frozen studies 005 Poise and 006 Folio. It is not regular study 007. No outside models or imagery are included. Source GLB geometry and PBR payloads remain unchanged; the new rounded support desk and ground are original minimal additions.

## Rebuild and check

Requires Blender 4.3.2, Node 24+ and Python 3. All paths resolve relative to this package; no account credentials or absolute private paths are required.

```
SAMPLES=512 WIDTH=1440 blender -b -t 8 --python-exit-code 1 --python source/build.py
python source/sanitize_public.py
blender -b -t 4 --python-exit-code 1 --python source/check-scene.py
node --loader ./source/local-loader.mjs source/test-spatial.mjs
node source/test-app-state.mjs
blender -b --python-exit-code 1 --python source/project-blender.py
node --loader ./source/local-loader.mjs source/test-geometry.mjs
python source/check-package.py --prearchive
python source/package.py
```

`dist/assets/scene.json` is the single Y-up spatial contract: source model hash, translation, rotation about Y, unit scale, vertical FOV, camera position/target, semantic hotspot point. Blender uses the explicit Y-up→Z-up conjugation, and each named chapter is saved as a camera timeline key (1, 31, 61). Three.js loads the unchanged original GLBs with the same transforms. The generated desk mesh is loaded directly. The same chapter camera and aspect ratio drive both renderers. Lighting engines are not photometrically equivalent; neither image similarity nor physical lux is claimed.

For a one-command verification pass without rerendering: `python source/verify.py`. This removes stale Blender reports, requires a success marker and nonzero failure exit handling, then verifies each fresh report explicitly.

## Interaction contract

- This is one world, not three swapped models. The two source objects remain in place in all views.
- Native anchors `#overview`, `#light`, `#fold` reveal complete static chapters. Nothing hides the reading content. Tab and Enter use native link behavior.
- Scene discs project from actual world points. The disc centre is the point; text labels sit to its right. Near-edge and behind-camera hotspots hide rather than clamp to misleading positions. The persistent full-scene link remains available.
- Stage aspect is fixed at 1.5 and matches the actual offline image. Changing aspect in a derivative requires rerendering posters and projection checks; do not apply cover cropping or independent letterboxing without mapping its content rectangle.
- At 320–390 CSS px, labels are omitted visually but full semantic names remain. Minimum target is 44×44 CSS px; on narrow screens the visible disc is only 19×19 without a halo, to preserve silhouettes. The overview hotspot was moved in world coordinates to avoid overlap on narrow layouts.
- Object raycasting is restricted to the two authored model groups. Blank desk and ground are not generic click targets. The overview is a deliberate hotspot or native link.
- Hash changes preserve browser Back/Forward. `#reading` records and restores the last scene with that history entry; it does not reset the camera.
- No scroll interception, auto-orbit, ambient animation or perpetual render loop. Reduced motion sets camera duration to zero; system preference and a visible checkbox are supported.
- Live 3D is opt-in, loading can be cancelled, and a live session can be explicitly returned to offline images. Route decoding and renderer sessions have independent cancellation tokens. Import/config/image/GL failures keep static text and native links. A failed chapter image does not relabel an old image as the new scene. Context loss disposes the canvas and returns to the poster.
- Layout gate: inspect the primary task area, not just horizontal overflow. On the tested desktop viewport, the whole desk, native chapter navigation, world hotspots and explicit 3D enable control must all be visible together without scrolling. Do not hide overflow or lock the document height to manufacture a pass.

## Verification boundary

Passed CPU and source checks do not validate real GPU shading, dynamic z-fighting, performance, pointer hit behavior on real WebGL, screen-reader interoperability or mobile hardware. Native cloud WebGL context creation is disabled; no settings were changed to bypass that restriction. Narrow iframe checks are CSS layout checks, not iPhone tests. See the reports for the exact checks and observed outcomes.

## Distribution

Public `dist` contains the experience, original source GLBs, generated `.blend`/`.glb`, three actual CPU posters, review and check reports. The source ZIP includes the scripts, shared config, before/after own-work evidence, and relevant documentation. It deliberately excludes external research screenshots, raw browser logs, failed binary test mutants, transient QA harnesses and private filesystem paths.

### Gallery return integration patch · 2026-11-01

The experience is mounted at `fusions/F03/index.html`. Its header and footer now provide native `../../index.html` links labelled “返回造物手记”, while the separate “回到案上” anchor stays within the scene. The source archive intentionally does not duplicate the enclosing gallery: standalone preview can read all content but the return link needs that deployment layout. The package gate permits only this exact, twice-present cross-boundary link and verifies its URL resolution; the host gallery must additionally test actual navigation. This patch changes no model, material, camera, stylesheet or JavaScript.
