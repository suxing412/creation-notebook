"""Desk Atlas — one Y-up config, original GLBs, real Cycles CPU scene. No external imagery."""
import bpy,json,math,os,hashlib
from pathlib import Path
from mathutils import Vector,Matrix
R=Path(__file__).resolve().parent.parent; A=R/'dist/assets';c=json.loads((A/'scene.json').read_text())
assert bpy.app.version==(4,3,2)
C=Matrix(((1,0,0,0),(0,0,-1,0),(0,1,0,0),(0,0,0,1)))
def xyz(v):return Vector((v[0],-v[2],v[1]))
def aim(o,p):o.rotation_euler=(xyz(p)-o.location).to_track_quat('-Z','Y').to_euler()
def material(name,color,roughness):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;p=m.node_tree.nodes['Principled BSDF'];p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=roughness;return m
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
for m in c['models']:
 assert hashlib.sha256((A/m['file']).read_bytes()).hexdigest()==m['sha256']
 bpy.ops.object.select_all(action='DESELECT');bpy.ops.import_scene.gltf(filepath=str(A/m['file']));imported=list(bpy.context.selected_objects);roots=[o for o in imported if o.parent not in imported]
 T=Matrix.Translation(Vector(m['position']))@Matrix.Rotation(m['rotationY'],4,'Y')@Matrix.Scale(m['scale'],4)
 for o in roots:o.matrix_world=C@T@C.inverted()@o.matrix_world
 for o in imported:o.name=m['id']+' / '+o.name
for k in ['support','ground']:
 d=c[k];bpy.ops.mesh.primitive_cube_add(size=1,location=xyz(d['position']));o=bpy.context.object;o.name='Desk Atlas / '+k;o.dimensions=(d['dimensions'][0],d['dimensions'][2],d['dimensions'][1]);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(material(k,d['color'],d['roughness']))
 if k=='support':
  bevel=o.modifiers.new('Rounded desk edge — new support only','BEVEL');bevel.width=d['bevel'];bevel.segments=5;bevel.affect='EDGES';bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=bevel.name)
  for p in o.data.polygons:p.use_smooth=True
  n=o.modifiers.new('Weighted corner normals','WEIGHTED_NORMAL');n.keep_sharp=True;bpy.ops.object.modifier_apply(modifier=n.name)
  bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.ops.export_scene.gltf(filepath=str(A/'desk.glb'),export_format='GLB',use_selection=True,export_extras=False)
bpy.ops.object.select_all(action='SELECT');bpy.ops.export_scene.gltf(filepath=str(A/'desk-atlas.glb'),export_format='GLB',use_selection=True,export_extras=False)
s=bpy.context.scene;s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.69,.72,.76,1);s.world.node_tree.nodes['Background'].inputs[1].default_value=.32
for d in c['lights']:
 bpy.ops.object.light_add(type='AREA',location=xyz(d['position']));o=bpy.context.object;o.name='Atlas light / '+d['id'];o.data.color=d['color'];o.data.energy=d['power'];o.data.shape='DISK';o.data.size=d['size'];aim(o,d['target'])
s.render.engine='CYCLES';s.cycles.device='CPU';s.cycles.samples=int(os.environ.get('SAMPLES','96'));s.cycles.use_denoising=False;s.render.resolution_x=int(os.environ.get('WIDTH','1440'));s.render.resolution_y=round(s.render.resolution_x/c['aspect']);s.render.resolution_percentage=100;s.view_settings.view_transform='AgX';s.view_settings.exposure=-.2;s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.render.image_settings.color_depth='8';s.render.film_transparent=False
bpy.ops.object.camera_add();cam=bpy.context.object;cam.name='Desk Atlas / route camera';s.camera=cam;cam.data.type='PERSP';cam.data.sensor_fit='VERTICAL';cam.data.sensor_height=24;cam.data.lens=24/(2*math.tan(math.radians(c['fov'])/2));cam.data.clip_start=c['near'];cam.data.clip_end=c['far']
for i,d in enumerate(c['routes']):
 s.frame_set(1+i*30)
 cam.location=xyz(d['position']);aim(cam,d['target']);cam.keyframe_insert(data_path='location',frame=1+i*30);cam.keyframe_insert(data_path='rotation_euler',frame=1+i*30);marker=s.timeline_markers.new(d['id'],frame=1+i*30);marker.camera=cam
 if not os.environ.get('ONLY_ROUTE') or os.environ['ONLY_ROUTE']==d['id']:
  s.render.filepath=str(A/d['image']);bpy.ops.render.render(write_still=True)
s.frame_set(1);s.render.filepath='//overview.png';s['project']='F03 / Desk Atlas';s['version']=c['version'];s['renderer']='Cycles CPU — not GPU evidence';s['seed']=0
for sc in bpy.data.screens:
 for area in sc.areas:
  for sp in area.spaces:
   if sp.type=='FILE_BROWSER' and sp.params:sp.params.directory=b'//'
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(A/'desk-atlas.blend'))
print('DESK_ATLAS_BUILD_COMPLETE')
