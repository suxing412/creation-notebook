"""Source/package gate. No browser, no GPU claim. Run before and after archive creation."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
import json,re,hashlib,struct,sys
R=Path(__file__).resolve().parent.parent;D=R/'dist';c=json.loads((D/'assets/scene.json').read_text());checks=[]
for m in c['models']:
 assert hashlib.sha256((D/'assets'/m['file']).read_bytes()).hexdigest()==m['sha256'];checks.append('frozen hash '+m['id'])
class Page(HTMLParser):
 def __init__(self):super().__init__();self.links=[];self.ids=[];self.images=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if 'id'in a:self.ids.append(a['id'])
  if tag in['a','link']and'href'in a:self.links.append(a['href'])
  if tag=='img':self.images.append(a);assert a.get('alt');self.links.append(a['src'])
  if tag=='script'and'src'in a:self.links.append(a['src'])
for file in D.rglob('*.html'):
 if '_qa'in file.parts:continue
 p=Page();p.feed(file.read_text());assert len(p.ids)==len(set(p.ids)),file.name
 for value in p.links:
  url=urlsplit(value)
  if url.scheme or url.netloc:continue
  # The standalone source intentionally does not duplicate its enclosing gallery.
  # Only this exact authored deployment link may cross the distribution boundary.
  if file==D/'index.html' and value=='../../index.html':
   from urllib.parse import urljoin
   assert urljoin('https://example.invalid/fusions/F03/index.html',value)=='https://example.invalid/index.html'
   continue
  target=file.parent/unquote(url.path) if url.path else file
  if target.name=='source.zip'and not target.exists()and'--prearchive'in sys.argv:continue
  assert target.exists(),(file.relative_to(D),value)
  if url.fragment and target.suffix=='.html':
   q=Page();q.feed(target.read_text());assert url.fragment in q.ids,(file.name,value)
 checks.append('HTML references '+str(file.relative_to(D)))
home=Page();home.feed((D/'index.html').read_text())
assert home.links.count('../../index.html')==2
assert '#overview' in home.links
checks.append('two native gallery returns resolve from /fusions/F03/ to /index.html; in-page overview retained (host integration checked separately)')
for path in D.rglob('*'):
 if not path.is_file()or'_qa'in path.parts or path.suffix=='.zip':continue
 b=path.read_bytes();assert not any(m in b for m in[('/'+x+'/').encode() for x in ['workspace','home'+'/agent','tmp']]+[("file"+":///").encode()]),path.relative_to(D)
 assert not path.name.endswith(('.log','.blend1','.pyc')),path.name
checks.append('public private-path / temporary-file scan')
for name in['overview','light','fold']:
 b=(D/'assets'/f'{name}.png').read_bytes();assert b[:8]==b'\x89PNG\r\n\x1a\n';width,height=struct.unpack_from('>II',b,16);assert (width,height)==(1440,960);assert b'tEXt'not in b and b'iTXt'not in b
checks.append('three 1440x960 PNG posters and stripped text metadata')
for name in['spatial-tests','scene-tests','independent-state-after','independent-geometry']:
 r=json.loads((D/'reports'/f'{name}.json').read_text());assert r['passed'];checks.append(name+' passed')
assert 'wheel' not in (D/'app.js').read_text();assert 'setInterval'not in(D/'app.js').read_text();checks.append('no wheel interception / interval loop')
report={'passed':True,'date':'2026-11-01','version':c['version'],'scope':'Package/source/static references only; not a GPU result.','checks':checks};(D/'reports/package-tests.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
