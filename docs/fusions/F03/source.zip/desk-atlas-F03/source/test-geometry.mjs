import fs from 'node:fs';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
import * as T from '../dist/vendor/three.module.js';
import {GLTFLoader} from '../dist/vendor/addons/loaders/GLTFLoader.js';
import {project} from '../dist/navigation.mjs';
const A=new URL('../dist/assets/',import.meta.url),c=JSON.parse(fs.readFileSync(new URL('scene.json',A))),b=JSON.parse(fs.readFileSync(new URL('../dist/reports/independent-projections.json',import.meta.url))),rows=[],loader=new GLTFLoader(),world=new T.Scene(),targets=[],modelBoxes={};
async function load(file){const bytes=fs.readFileSync(new URL(file,A));return (await loader.parseAsync(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength),'')).scene}
for(const m of c.models){const root=await load(m.file);root.position.fromArray(m.position);root.rotation.y=m.rotationY;root.scale.setScalar(m.scale);world.add(root);root.traverse(o=>{if(o.isMesh){o.userData.route=m.route;targets.push(o)}});root.updateMatrixWorld(true);modelBoxes[m.id]=new T.Box3().setFromObject(root)}
const support=await load(c.support.file);world.add(support);world.updateMatrixWorld(true);const deskBox=new T.Box3().setFromObject(support);assert(Math.abs(deskBox.max.y)<1e-8);
const contacts=c.models.map(m=>({id:m.id,gapM:modelBoxes[m.id].min.y-deskBox.max.y}));assert(contacts.every(x=>Math.abs(x.gapM)<1e-6));
let maxProjectionError=0;const ray=new T.Raycaster();
for(const r of c.routes){
 const camera=new T.PerspectiveCamera(c.fov,c.aspect,c.near,c.far);camera.position.fromArray(r.position);camera.lookAt(...r.target);camera.updateMatrixWorld(true);camera.updateProjectionMatrix();
 const projections=[];
 for(const t of c.routes){const cp=project(t.hotspot,r,c.fov,c.aspect),v=new T.Vector3(...t.hotspot).project(camera),bp=b.rows.find(x=>x.camera===r.id&&x.hotspot===t.id);const err=Math.max(Math.abs(cp.x-bp.x),Math.abs(cp.y-bp.y));maxProjectionError=Math.max(maxProjectionError,err);assert(err<2e-6);assert(Math.abs(cp.x-(v.x+1)/2)<1e-12&&Math.abs(cp.y-(1-v.y)/2)<1e-12);projections.push({hotspot:t.id,uv:[cp.x,cp.y],visible:cp.visible,blenderVsThreeMaxUV:err});}
 let blankDeskHits=0,incorrectBlankNavigation=0,sourceHits=0,frontSourceMismatch=0;
 for(let iy=0;iy<25;iy++)for(let ix=0;ix<37;ix++){
  const uv=new T.Vector2((ix+.5)/37*2-1,1-(iy+.5)/25*2);ray.setFromCamera(uv,camera);
  const all=ray.intersectObject(world,true),selected=ray.intersectObjects(targets,false),front=all[0];
  if(!front)continue;
  if(!front.object.userData.route){blankDeskHits++;if(selected.length)incorrectBlankNavigation++;}
  else {sourceHits++;if(!selected[0]||selected[0].object.userData.route!==front.object.userData.route)frontSourceMismatch++;}
 }
 assert(blankDeskHits>0&&sourceHits>0);assert.equal(incorrectBlankNavigation,0);assert.equal(frontSourceMismatch,0);
 const viewportChecks=[320,390,768,1173,1440].map(width=>{const stageWidth=width<=650?.88*width:width<=900?(width*.91-25)*1.3/2.3:(width*.91-width*.04)*1.8/2.8;const stageHeight=stageWidth/c.aspect;const visible=projections.filter(p=>p.visible&&p.uv[0]>Math.max(40/stageWidth,.06)&&p.uv[0]<1-Math.max(40/stageWidth,.06));let minSeparation=null;for(let i=0;i<visible.length;i++)for(let j=0;j<i;j++){const dx=Math.abs(visible[i].uv[0]-visible[j].uv[0])*stageWidth,dy=Math.abs(visible[i].uv[1]-visible[j].uv[1])*stageHeight;const separation=Math.max(dx,dy)-44;minSeparation=minSeparation===null?separation:Math.min(minSeparation,separation);assert(separation>=0)}return {viewportCSSWidth:width,estimatedStageWidth:stageWidth,visibleHotspots:visible.map(p=>p.hotspot),min44pxTargetAxisGap:minSeparation}});
 rows.push({route:r.id,projections,rayGrid:{rays:925,blankDeskHits,incorrectBlankNavigation,sourceHits,frontSourceMismatch},viewportChecks});
}
console.log(JSON.stringify({passed:true,scope:'Actual GLB via Three GLTFLoader, numeric Blender/Three projection, CPU ray tests. Viewport widths are CSS algebra, not browser layout. No GPU.',threeRevision:T.REVISION,blender:b.engine+'/'+b.device,renderResolution:b.resolution,renderSamples:b.samples,maxProjectionErrorUV:maxProjectionError,deskBounds:{min:deskBox.min.toArray(),max:deskBox.max.toArray()},contacts,rows},null,2));
