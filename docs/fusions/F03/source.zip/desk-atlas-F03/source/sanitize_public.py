"""Strip PNG text metadata and Blender file-browser directory buffers.
No geometry/material edits; validate the result again with the Blender checkers.
"""
from pathlib import Path
import struct,re,json,hashlib
from PIL import Image
root=Path(__file__).resolve().parents[1]/'dist/assets';report={'png':[],'blend':[]}
for p in [*root.glob('*.png'),*(root.parent.parent/'qa/before').glob('*.png')]:
 before=hashlib.sha256(Image.open(p).tobytes()).hexdigest();b=p.read_bytes();assert b[:8]==b'\x89PNG\r\n\x1a\n';out=b[:8];o=8;removed=[]
 while o<len(b):
  n=struct.unpack_from('>I',b,o)[0];typ=b[o+4:o+8];chunk=b[o:o+12+n]
  if typ in [b'tEXt',b'zTXt',b'iTXt']:removed.append(typ.decode())
  else:out+=chunk
  o+=12+n
 p.write_bytes(out);after=hashlib.sha256(Image.open(p).tobytes()).hexdigest();assert before==after;report['png'].append({'file':p.name,'removedTextChunks':len(removed),'decodedPixelsUnchanged':True})
for p in root.glob('*.blend'):
 b=bytearray(p.read_bytes());originalLength=len(b);assert b[:9]==b'BLENDER-v';blocks=[];o=12
 while o<len(b):
  code,n,ptr,sdna,count=struct.unpack_from('<4sIQII',b,o);blocks.append((code,o+24,n,sdna,count));o+=24+n
  if code==b'ENDB':break
 start=next(t for t in blocks if t[0]==b'DNA1')[1];d=b[start:];o=8;n=struct.unpack_from('<I',d,o)[0];o+=4;names=[]
 for i in range(n):q=d.index(0,o);names.append(d[o:q].decode());o=q+1
 o=(o+3)//4*4;assert d[o:o+4]==b'TYPE';o+=4;n=struct.unpack_from('<I',d,o)[0];o+=4;types=[]
 for i in range(n):q=d.index(0,o);types.append(d[o:q].decode());o=q+1
 o=(o+3)//4*4;assert d[o:o+4]==b'TLEN';o+=4;lens=struct.unpack_from('<'+'H'*n,d,o);o+=n*2;o=(o+3)//4*4;assert d[o:o+4]==b'STRC';o+=4;n=struct.unpack_from('<I',d,o)[0];o+=4;structs=[]
 for si in range(n):
  typ,nf=struct.unpack_from('<HH',d,o);o+=4;fields=[]
  for j in range(nf):t,name=struct.unpack_from('<HH',d,o);o+=4;fields.append((types[t],names[name],lens[t]))
  structs.append((types[typ],fields))
 count=0
 for si,(name,fields) in enumerate(structs):
  if name!='FileSelectParams':continue
  assert fields[0][0]=='char' and fields[0][1].startswith('title[') and fields[1][0]=='char' and fields[1][1].startswith('dir[')
  offset=int(re.search(r'\[(\d+)\]',fields[0][1])[1]);length=int(re.search(r'\[(\d+)\]',fields[1][1])[1])
  for code,pos,size,dna,num in blocks:
   if dna==si:
    assert num==1;b[pos+offset:pos+offset+length]=b'//'+b'\0'*(length-2);count+=1
 # Render output's default directory is non-geometric metadata; retain byte length.
 b=b.replace(b'/'+b'tmp/'+b'\0',b'//\0\0\0\0')
 p.write_bytes(b);report['blend'].append({'file':p.name,'directoryBuffersCleared':count,'byteLengthPreserved':len(b)==originalLength,'geometryReopenRequired':True})
(root/'metadata-cleanup.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
