import bpy, json, math
from pathlib import Path
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
R=Path(__file__).resolve().parent.parent;A=R/'dist/assets';c=json.loads((A/'scene.json').read_text())
bpy.ops.wm.open_mainfile(filepath=str(A/'desk-atlas.blend'))
s=bpy.context.scene;cam=s.camera
assert s.render.resolution_x==1440 and s.render.resolution_y==960
assert s.render.pixel_aspect_x==1 and s.render.pixel_aspect_y==1
assert not s.render.use_border
assert abs(cam.data.shift_x)<1e-8 and abs(cam.data.shift_y)<1e-8
assert cam.data.sensor_fit=='VERTICAL'
rows=[]
for i,r in enumerate(c['routes']):
 s.frame_set(1+i*30)
 for t in c['routes']:
  p=world_to_camera_view(s,cam,Vector((t['hotspot'][0],-t['hotspot'][2],t['hotspot'][1])))
  rows.append({'camera':r['id'],'hotspot':t['id'],'x':p.x,'y':1-p.y,'depth':p.z})
(R/'dist/reports/independent-projections.json').write_text(json.dumps({'engine':s.render.engine,'device':s.cycles.device,'samples':s.cycles.samples,'resolution':[s.render.resolution_x,s.render.resolution_y],'verticalFOV':math.degrees(2*math.atan(cam.data.sensor_height/(2*cam.data.lens))),'rows':rows},indent=2))
print('INDEPENDENT_BLENDER_PROJECTION_PASS')
