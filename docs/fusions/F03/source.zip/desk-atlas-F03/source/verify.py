"""Run native CPU/source gates and require fresh, explicit success reports."""
from pathlib import Path
import subprocess,json,sys
R=Path(__file__).resolve().parent.parent;D=R/'dist';S=R/'source'
def run(args):return subprocess.run(args,cwd=R,text=True,capture_output=True,check=True)
def blender(script,report,marker):
 p=D/'reports'/report;p.unlink(missing_ok=True);r=run(['blender','-b','-t','4','--python-exit-code','1','--python',str(S/script)]);assert marker in r.stdout;assert p.exists();return json.loads(p.read_text())
for name in['app.js','navigation.mjs']:run(['node','--check',str(D/name)])
assert blender('check-scene.py','scene-tests.json','DESK_ATLAS_SCENE_TESTS_PASS')['passed']
blender('project-blender.py','independent-projections.json','INDEPENDENT_BLENDER_PROJECTION_PASS')
run(['node','--loader',str(S/'local-loader.mjs'),str(S/'test-spatial.mjs')]);assert json.loads((D/'reports/spatial-tests.json').read_text())['passed']
for script,report,extra in[('test-app-state.mjs','independent-state-after.json',[]),('test-geometry.mjs','independent-geometry.json',['--loader',str(S/'local-loader.mjs')])]:
 r=run(['node',*extra,str(S/script)]);data=json.loads(r.stdout);assert data['passed'];(D/'reports'/report).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
run([sys.executable,str(S/'check-package.py'),'--prearchive']);print('F03_NATIVE_CPU_AND_SOURCE_CHECKS_PASS — GPU NOT TESTED')
