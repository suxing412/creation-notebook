"""Reopen real Blender and assembled GLB, compare immutable inputs and every named route."""
import bpy,json,math,hashlib,struct
from pathlib import Path
from mathutils import Vector,Matrix,kdtree
from bpy_extras.object_utils import world_to_camera_view
R=Path(__file__).resolve().parent.parent;A=R/'dist/assets';c=json.loads((A/'scene.json').read_text());reports=[]
C=Matrix(((1,0,0,0),(0,0,-1,0),(0,1,0,0),(0,0,0,1)))
def xyz(v):return Vector((v[0],-v[2],v[1]))
def glbjson(p):
 b=p.read_bytes();n=struct.unpack_from('<I',b,12)[0];return json.loads(b[20:20+n])
def clean():bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
assembled=glbjson(A/'desk-atlas.glb')
for m in c['models']:
 original=glbjson(A/m['file']);assert hashlib.sha256((A/m['file']).read_bytes()).hexdigest()==m['sha256']
 for mat in original['materials']:assert mat in assembled['materials'],mat['name']
 reports.append({'check':'PBR payload unchanged / '+m['id'],'passed':True,'materials':[m['name'] for m in original['materials']]})
clean();bpy.ops.import_scene.gltf(filepath=str(A/'desk-atlas.glb'));actual={m['id']:[o.matrix_world@v.co for o in bpy.data.objects if o.type=='MESH' and o.name.startswith(m['id']+' / ') for v in o.data.vertices] for m in c['models']}
for m in c['models']:
 clean();bpy.ops.import_scene.gltf(filepath=str(A/m['file']));T=C@Matrix.Translation(Vector(m['position']))@Matrix.Rotation(m['rotationY'],4,'Y')@Matrix.Scale(m['scale'],4)@C.inverted();expected=[T@o.matrix_world@v.co for o in bpy.data.objects if o.type=='MESH' for v in o.data.vertices];got=actual[m['id']];errors=[]
 for points,other in [(expected,got),(got,expected)]:
  tree=kdtree.KDTree(len(points))
  for i,p in enumerate(points):tree.insert(p,i)
  tree.balance();errors.extend(tree.find(p)[2] for p in other)
 assert max(errors)<5e-6
 reports.append({'check':'assembled world geometry / '+m['id'],'passed':True,'sourceVertices':len(expected),'assembledVertices':len(got),'topologyIndexIdentityClaimed':False,'bidirectionalNearestMaxMetres':max(errors),'thresholdMetres':5e-6})
bpy.ops.wm.open_mainfile(filepath=str(A/'desk-atlas.blend'));s=bpy.context.scene;cam=s.camera
assert s.render.engine=='CYCLES' and s.cycles.device=='CPU';assert cam.data.sensor_fit=='VERTICAL';fov=math.degrees(2*math.atan(cam.data.sensor_height/(2*cam.data.lens)));assert abs(fov-c['fov'])<1e-4
for i,r in enumerate(c['routes']):
 s.frame_set(1+i*30);expected=xyz(r['position']);assert (cam.location-expected).length<1e-6;forward=cam.matrix_world.to_quaternion()@Vector((0,0,-1));target=(xyz(r['target'])-cam.location).normalized();assert (forward-target).length<1e-5
 p=world_to_camera_view(s,cam,xyz(r['hotspot']));assert 0<p.x<1 and 0<p.y<1
 reports.append({'check':'saved Blender camera / '+r['id'],'passed':True,'frame':1+i*30,'positionYUp':r['position'],'verticalFOVDegrees':fov,'hotspotScreenUV':[p.x,1-p.y],'cameraForwardError':(forward-target).length})
assert len(set(hashlib.sha256((A/r['image']).read_bytes()).hexdigest() for r in c['routes']))==3
reports.append({'check':'three different camera images','passed':True})
for obj in bpy.data.objects:
 if obj.type=='MESH':assert all(math.isfinite(a) for v in obj.data.vertices for a in v.co)
reports.append({'check':'reopened scene finite vertices','passed':True})
(A.parent/'reports/scene-tests.json').write_text(json.dumps({'passed':True,'scope':'Actual Blender file reopen, actual assembled GLB and frozen GLB payload comparisons; CPU only.','tests':reports},indent=2));print('DESK_ATLAS_SCENE_TESTS_PASS')
