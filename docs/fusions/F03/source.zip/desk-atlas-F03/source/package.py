"""Rebuild the self-contained source ZIP from an allowlisted, sanitized tree."""
from pathlib import Path
import zipfile,json,hashlib,subprocess,sys
R=Path(__file__).resolve().parent.parent;D=R/'dist';A=D/'assets';c=json.loads((A/'scene.json').read_text())
subprocess.run([sys.executable,str(R/'source/check-package.py'),'--prearchive'],check=True)
reg=json.loads((A/'asset-registry.json').read_text());reg['files']=[]
for p in sorted(A.iterdir()):
 if p.is_file()and p.name!='asset-registry.json':reg['files'].append({'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(A/'asset-registry.json').write_text(json.dumps(reg,ensure_ascii=False,indent=2)+'\n')
files=[]
for folder in[D,R/'source']:
 for p in sorted(folder.rglob('*')):
  if p.is_file()and not any(x in p.parts for x in['_qa','__pycache__'])and p.suffix not in['.zip','.pyc','.log']and not p.name.endswith('.blend1'):
   files.append((p,str(p.relative_to(R))))
for p in sorted((R/'qa/before').glob('*')):
 if p.is_file()and p.suffix in['.js','.mjs','.html','.css','.json','.png']:files.append((p,'history/v0.1/'+p.name))
for p,arc in files:
 b=p.read_bytes();assert not any(t in b for t in[('/'+x+'/').encode() for x in ['workspace','home'+'/agent','tmp']]),arc
with zipfile.ZipFile(D/'source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=8)as z:
 for p,arc in files:
  info=zipfile.ZipInfo('desk-atlas-F03/'+arc,date_time=(2026,11,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16;z.writestr(info,p.read_bytes())
subprocess.run([sys.executable,str(R/'source/check-package.py')],check=True)
print('SOURCE_ARCHIVE',hashlib.sha256((D/'source.zip').read_bytes()).hexdigest(),(D/'source.zip').stat().st_size)
