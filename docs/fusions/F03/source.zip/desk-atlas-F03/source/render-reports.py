"""Small dependency-free renderer for this repository's trusted, simple report Markdown."""
from pathlib import Path
import html,re
R=Path(__file__).resolve().parent.parent; D=R/'dist/reports'
def inline(s):
 s=html.escape(s);s=re.sub(r'`([^`]+)`',r'<code>\1</code>',s);s=re.sub(r'\*\*([^*]+)\*\*',r'<strong>\1</strong>',s);s=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'<a href="\2">\1</a>',s);return s
css='body{font:16px/1.9 system-ui;color:#302b24;background:#eee9df;max-width:980px;padding:4vw;margin:auto}h1,h2,h3{font-family:Georgia,serif;line-height:1.4}h1{font-size:40px}h2{margin-top:50px}a{color:#775038}code{overflow-wrap:anywhere;font-size:.85em}img{max-width:100%;height:auto}figure{margin:20px 0}figcaption{font-size:12px;color:#6b6255}.pair{display:grid;grid-template-columns:1fr 1fr;gap:20px}.note{border-left:3px solid #8d765f;padding:12px 20px}@media(max-width:650px){.pair{display:block}body{font-size:14px}h1{font-size:30px}}'
for name in ['review','qa']:
 out=[];lines=(D/f'{name}.md').read_text().splitlines();ul=False
 for line in lines:
  if not line.strip():
   if ul:out.append('</ul>');ul=False
   continue
  if line.startswith('- '):
   if not ul:out.append('<ul>');ul=True
   out.append('<li>'+inline(line[2:])+'</li>');continue
  if ul:out.append('</ul>');ul=False
  m=re.match(r'^(#{1,3}) (.*)',line)
  if m:out.append(f'<h{len(m[1])}>'+inline(m[2])+f'</h{len(m[1])}>')
  else:out.append('<p>'+inline(line)+'</p>')
 if ul:out.append('</ul>')
 if name=='review':out.append('<h2>自己的前后图</h2><div class="pair"><figure><img src="images/before-desktop.jpg" alt="首版：大标题将空间推到下半屏"><figcaption>首版页面</figcaption></figure><figure><img src="images/after-desktop.jpg" alt="修订：完整桌面与目录、启用入口同屏"><figcaption>修订页面</figcaption></figure></div><div class="pair"><figure><img src="../assets/fold-before.png" alt="首版96样本折页CPU图"><figcaption>首版 96 samples / CPU</figcaption></figure><figure><img src="../assets/fold.png" alt="修订512样本折页CPU图"><figcaption>修订 512 samples / CPU；非实时验收</figcaption></figure></div>')
 (D/f'{name}.html').write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>F03 · '+('评审与复盘' if name=='review' else '检查记录')+'</title><style>'+css+'</style><a href="../index.html">← 回到案上秩序</a>'+''.join(out)+'</html>')
print('REPORTS_RENDERED')
