import bpy,json,os,hashlib,math
from mathutils import Vector
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));OUT=os.path.join(ROOT,'dist','assets');cfg=json.load(open(os.path.join(OUT,'scene.json')))
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);bpy.ops.import_scene.gltf(filepath=os.path.join(OUT,'scales-scene.glb'))
bounds={};deg=dup=tris=0;objects=0
for o in bpy.context.scene.objects:
 if o.type!='MESH':continue
 objects+=1;o.data.calc_loop_triangles();seen=set()
 pts=[o.matrix_world@Vector(v) for v in o.bound_box];bounds[o.name]=[[min(p[i] for p in pts) for i in range(3)],[max(p[i] for p in pts) for i in range(3)]]
 for t in o.data.loop_triangles:
  vs=[o.matrix_world@o.data.vertices[i].co for i in t.vertices];tris+=1;deg+=int((vs[1]-vs[0]).cross(vs[2]-vs[0]).length*.5<1e-10);key=tuple(sorted(tuple(round(v,7) for v in p) for p in vs));dup+=int(key in seen);seen.add(key)
groups={}
for prefix in ['iris','limen','Interpretive']:
 bs=[b for n,b in bounds.items() if n.startswith(prefix)];groups[prefix]=[[min(b[0][i] for b in bs) for i in range(3)],[max(b[1][i] for b in bs) for i in range(3)]]
overlaps=[]
keys=list(groups)
for i,a in enumerate(keys):
 for b in keys[i+1:]:
  ext=[min(groups[a][1][j],groups[b][1][j])-max(groups[a][0][j],groups[b][0][j]) for j in range(3)]
  if min(ext)>1e-6:overlaps.append([a,b,ext])
hits=[];samples=0
for a in cfg['routes']:
 for b in cfg['routes']:
  if a==b:continue
  for j in range(101):
   t=j/100;t=t*t*(3-2*t);v=[a['position'][i]+(b['position'][i]-a['position'][i])*t for i in range(3)];p=[v[0],-v[2],v[1]];samples+=1
   for name,box in bounds.items():
    if all(box[0][i]-.15<p[i]<box[1][i]+.15 for i in range(3)):hits.append([a['id'],b['id'],j,name])
result={'meshObjects':objects,'triangles':tris,'degenerateTriangles':deg,'sameMeshDuplicateTriangles':dup,'assemblyGroupAABBOverlapCandidates':overlaps,'groupBoundsBlenderZUp':groups,'sampledCameraPositions':samples,'cameraRadiusPadding':.15,'cameraAABBHits':hits,'limits':'Finite samples and conservative object AABBs only. No continuous collision or full self-intersection claim. Original assembly joints inherit study QA; no iris animation. GPU z-fighting and phone unverified.'}
json.dump(result,open(os.path.join(ROOT,'dist','reports','geometry.json'),'w'),indent=2);print(json.dumps(result))
