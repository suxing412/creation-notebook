# F02 Scales of Seeing

Build with Blender 4.3.2 only:

    blender -b -P source/build.py
    blender -b -P source/check.py
    blender -b -P source/check-transforms.py
    node source/test-navigation.mjs
    python source/sanitize_public.py
    python source/package.py

Use a static HTTP server for dist. No external API, CDN, or secret required. Three.js r180 is vendored under its original MIT license.

Inputs: dist/assets/iris.glb and limen.glb are byte-identical original studies. Source provenance and hashes are in asset-registry.json. scene.json defines their transforms, static iris reference state, vertical camera FOV and chapter routes. build.py imports without editing source files, then writes a derived assembly GLB and editable Blender scene. GLB re-export can split vertices for normals/material attributes; vertex count identity is NOT claimed. check-transforms.py verifies bidirectional world point proximity, separately from source byte identity.

navigation.mjs is reusable independently of renderer. Camera interpolation is explicit destination-to-destination smoothstep. No scroll coupling or free movement. Web content remains in semantic document flow. For other geometry, replace source assets, register provenance, choose camera destinations and rerun ALL geometry and visual checks; do not reuse camera coordinates blindly.

Reports list actual tested bounds and limitations. Never treat CPU, static imagery or iframe tests as GPU or phone validation.
