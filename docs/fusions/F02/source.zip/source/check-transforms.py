import bpy,json,os
from mathutils import Vector,Matrix,kdtree
R=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));A=os.path.join(R,'dist','assets');c=json.load(open(os.path.join(A,'scene.json')))
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);bpy.ops.import_scene.gltf(filepath=os.path.join(A,'scales-scene.glb'))
actual={m['id']:[o.matrix_world@v.co for o in bpy.data.objects if o.type=='MESH' and o.name.startswith(m['id']+' / ') for v in o.data.vertices] for m in c['models']}
C=Matrix(((1,0,0,0),(0,0,-1,0),(0,1,0,0),(0,0,0,1)));result=[]
for m in c['models']:
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);bpy.ops.import_scene.gltf(filepath=os.path.join(A,m['file']))
 T=C@Matrix.Translation(Vector(m['position']))@Matrix.Rotation(m['rotationX'],4,'X')@Matrix.Scale(m['scale'],4)@C.inverted()
 exp=[T@o.matrix_world@v.co for o in bpy.data.objects if o.type=='MESH' for v in o.data.vertices];got=actual[m['id']];errors=[]
 for points,other in [(exp,got),(got,exp)]:
  kd=kdtree.KDTree(len(points))
  for i,p in enumerate(points):kd.insert(p,i)
  kd.balance();errors.extend(kd.find(p)[2] for p in other)
 result.append({'model':m['id'],'originalVertices':len(exp),'assembledVertices':len(got),'bidirectionalNearestVertexMaxError':max(errors),'threshold':5e-6,'passed':max(errors)<5e-6})
json.dump({'transforms':result,'scope':'Source GLB vertices transformed with shared Y-up registry vs assembled GLB; nearest-point check, not topology identity or GPU rendering.'},open(os.path.join(R,'dist','reports','transforms.json'),'w'),indent=2);print(result)
