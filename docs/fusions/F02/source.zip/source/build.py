import bpy,json,math,os
from mathutils import Vector,Matrix
assert bpy.app.version == (4,3,2), 'Validated only with Blender 4.3.2'
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));OUT=os.path.join(ROOT,'dist','assets')
cfg=json.load(open(os.path.join(OUT,'scene.json')))
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def xyz(p):return Vector((p[0],-p[2],p[1]))
# Conjugate Three's Y-up transform into Blender's Z-up coordinates.
C=Matrix(((1,0,0,0),(0,0,-1,0),(0,1,0,0),(0,0,0,1)))
for m in cfg['models']:
 bpy.ops.object.select_all(action='DESELECT');bpy.ops.import_scene.gltf(filepath=os.path.join(OUT,m['file']))
 imported=list(bpy.context.selected_objects); roots=[o for o in imported if o.parent not in imported]
 t=Matrix.Translation(Vector(m['position']))@Matrix.Rotation(m['rotationX'],4,'X')@Matrix.Scale(m['scale'],4)
 for o in roots:o.matrix_world=C@t@C.inverted()@o.matrix_world
 for o in imported:o.name=m['id']+' / '+o.name
# Base only; no imported geometry edits or extra decorative architecture.
mat=bpy.data.materials.new('Coastal linen');mat.diffuse_color=(.43,.46,.45,1);mat.use_nodes=True;mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(.43,.46,.45,1);mat.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.87
bpy.ops.mesh.primitive_cube_add(size=1,location=(0,0,-.8));o=bpy.context.object;o.name='Interpretive ground';o.dimensions=(34,32,.5);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(mat)
bpy.ops.object.select_all(action='SELECT');bpy.ops.export_scene.gltf(filepath=os.path.join(OUT,'scales-scene.glb'),export_format='GLB',use_selection=True)
scene=bpy.context.scene;scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.44,.49,.52,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.55
for p,power,size in [((-8,12,10),2800,10),((8,9,-7),2200,8)]:
 bpy.ops.object.light_add(type='AREA',location=xyz(p));o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.rotation_euler=(xyz((0,1,-1))-o.location).to_track_quat('-Z','Y').to_euler()
scene.render.engine='CYCLES';scene.cycles.samples=48;scene.cycles.use_denoising=False;scene.render.resolution_x=1440;scene.render.resolution_y=960;scene.render.resolution_percentage=100;scene.view_settings.view_transform='AgX'
bpy.ops.object.camera_add();cam=bpy.context.object;scene.camera=cam;cam.data.type='PERSP';cam.data.sensor_fit='VERTICAL';cam.data.sensor_height=24;cam.data.lens=24/(2*math.tan(math.radians(cfg['fov'])/2))
for r in cfg['routes']:
 if os.environ.get('ONLY_ROUTE') and r['id']!=os.environ['ONLY_ROUTE']:continue
 cam.location=xyz(r['position']);cam.rotation_euler=(xyz(r['target'])-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=os.path.join(OUT,r['image']);bpy.ops.render.render(write_still=True)
scene.render.filepath='//observation.png'
for s in bpy.data.screens:
 for a in s.areas:
  for sp in a.spaces:
   if sp.type=='FILE_BROWSER' and sp.params:sp.params.directory=b'//'
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT,'scales-scene.blend'))
